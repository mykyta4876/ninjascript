﻿namespace NinjaTrader.NinjaScript.Strategies.Givanne.Gui
{
    public class ChartUserInterface
    {
        public BrushSettings BrushSettings { get; set; } = new BrushSettings();
        public ButtonPanel ButtonPanel {get; set;} = new ButtonPanel();
    }

    
}
