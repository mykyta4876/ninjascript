﻿using NinjaTrader.NinjaScript.Indicators;

namespace NinjaTrader.NinjaScript.Strategies
{
    public class TechnicalIndicators
    {
        public ATR Atr { get; set; }
        public EMA Ema { get; set; }
    }
}