using System.Windows.Media;

namespace NinjaTrader.NinjaScript.Strategies.Givanne.Gui
{
	public class BrushSettings
	{
		public Brush FillBrush { get; set; }
		public Brush LateDayBrush { get; set; }
		public Brush MorningBrush { get; set; }
		public Brush AfternoonBrush { get; set; }
	}
}