
I think ButtonPanel has good functionalities.
1. set limit order with trailing stop. 
2. custom quantity
we can refer these.


I don't think ButtonPanel has trailing stoploss.
it used ATM for setting static SL and TP, so we don't need ATM.
I found a way for trailing stoploss without error through this strategy.
And Unlike my code, this strategy uses Account class.
I think it's useful for us.

And this strategy support single trade, not multi trades.


