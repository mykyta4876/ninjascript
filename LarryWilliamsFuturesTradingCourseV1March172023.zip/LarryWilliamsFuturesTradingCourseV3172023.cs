#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private LW.WilliamsCOTCommercialIndexFC[] cacheWilliamsCOTCommercialIndexFC;
		private LW.WilliamsCOTCommericalNetPositionsFC[] cacheWilliamsCOTCommericalNetPositionsFC;
		private LW.WilliamsCOTLargeSpecIndexFC[] cacheWilliamsCOTLargeSpecIndexFC;
		private LW.WilliamsCOTLargeSpecNetPositionsFC[] cacheWilliamsCOTLargeSpecNetPositionsFC;
		private LW.WilliamsCOTNetPositionsOIFC[] cacheWilliamsCOTNetPositionsOIFC;
		private LW.WilliamsCOTOpenInterestFC[] cacheWilliamsCOTOpenInterestFC;
		private LW.WilliamsCOTSmallSpecIndexFC[] cacheWilliamsCOTSmallSpecIndexFC;
		private LW.WilliamsCOTSmallSpecNetPositionsFC[] cacheWilliamsCOTSmallSpecNetPositionsFC;
		private LW.WilliamsPatternsFC[] cacheWilliamsPatternsFC;
		private LW.WilliamsPaunchIndexFC[] cacheWilliamsPaunchIndexFC;
		private LW.WilliamsPctRFC[] cacheWilliamsPctRFC;
		private LW.WilliamsPOIVFC[] cacheWilliamsPOIVFC;
		private LW.WilliamsProGoProfessionalFC[] cacheWilliamsProGoProfessionalFC;
		private LW.WilliamsProGoPublicFC[] cacheWilliamsProGoPublicFC;
		private LW.WilliamsSentimentIndexFC[] cacheWilliamsSentimentIndexFC;
		private LW.WilliamsSpreadDifferenceFC[] cacheWilliamsSpreadDifferenceFC;
		private LW.WilliamsTargetShooter3[] cacheWilliamsTargetShooter3;
		private LW.WilliamsTrueHigh[] cacheWilliamsTrueHigh;
		private LW.WilliamsTrueLow[] cacheWilliamsTrueLow;
		private LW.WilliamsTrueRangeFC[] cacheWilliamsTrueRangeFC;
		private LW.WilliamsTrueSeasonalFC[] cacheWilliamsTrueSeasonalFC;
		private LW.WilliamsTurtleChannelFC[] cacheWilliamsTurtleChannelFC;
		private LW.WilliamsWildersVolatilityFC[] cacheWilliamsWildersVolatilityFC;
		private LW.WilliamsWillStopFC[] cacheWilliamsWillStopFC;
		private LW.WilliamsWillValFC[] cacheWilliamsWillValFC;

		
		public LW.WilliamsCOTCommercialIndexFC WilliamsCOTCommercialIndexFC(int lookBack)
		{
			return WilliamsCOTCommercialIndexFC(Input, lookBack);
		}

		public LW.WilliamsCOTCommericalNetPositionsFC WilliamsCOTCommericalNetPositionsFC()
		{
			return WilliamsCOTCommericalNetPositionsFC(Input);
		}

		public LW.WilliamsCOTLargeSpecIndexFC WilliamsCOTLargeSpecIndexFC(int lookBack)
		{
			return WilliamsCOTLargeSpecIndexFC(Input, lookBack);
		}

		public LW.WilliamsCOTLargeSpecNetPositionsFC WilliamsCOTLargeSpecNetPositionsFC()
		{
			return WilliamsCOTLargeSpecNetPositionsFC(Input);
		}

		public LW.WilliamsCOTNetPositionsOIFC WilliamsCOTNetPositionsOIFC()
		{
			return WilliamsCOTNetPositionsOIFC(Input);
		}

		public LW.WilliamsCOTOpenInterestFC WilliamsCOTOpenInterestFC()
		{
			return WilliamsCOTOpenInterestFC(Input);
		}

		public LW.WilliamsCOTSmallSpecIndexFC WilliamsCOTSmallSpecIndexFC(int lookBack)
		{
			return WilliamsCOTSmallSpecIndexFC(Input, lookBack);
		}

		public LW.WilliamsCOTSmallSpecNetPositionsFC WilliamsCOTSmallSpecNetPositionsFC()
		{
			return WilliamsCOTSmallSpecNetPositionsFC(Input);
		}

		public LW.WilliamsPatternsFC WilliamsPatternsFC()
		{
			return WilliamsPatternsFC(Input);
		}

		public LW.WilliamsPaunchIndexFC WilliamsPaunchIndexFC()
		{
			return WilliamsPaunchIndexFC(Input);
		}

		public LW.WilliamsPctRFC WilliamsPctRFC(int period)
		{
			return WilliamsPctRFC(Input, period);
		}

		public LW.WilliamsPOIVFC WilliamsPOIVFC()
		{
			return WilliamsPOIVFC(Input);
		}

		public LW.WilliamsProGoProfessionalFC WilliamsProGoProfessionalFC()
		{
			return WilliamsProGoProfessionalFC(Input);
		}

		public LW.WilliamsProGoPublicFC WilliamsProGoPublicFC()
		{
			return WilliamsProGoPublicFC(Input);
		}

		public LW.WilliamsSentimentIndexFC WilliamsSentimentIndexFC()
		{
			return WilliamsSentimentIndexFC(Input);
		}

		public LW.WilliamsSpreadDifferenceFC WilliamsSpreadDifferenceFC()
		{
			return WilliamsSpreadDifferenceFC(Input);
		}

		public LW.WilliamsTargetShooter3 WilliamsTargetShooter3(int extendTargetBars)
		{
			return WilliamsTargetShooter3(Input, extendTargetBars);
		}

		public LW.WilliamsTrueHigh WilliamsTrueHigh()
		{
			return WilliamsTrueHigh(Input);
		}

		public LW.WilliamsTrueLow WilliamsTrueLow()
		{
			return WilliamsTrueLow(Input);
		}

		public LW.WilliamsTrueRangeFC WilliamsTrueRangeFC()
		{
			return WilliamsTrueRangeFC(Input);
		}

		public LW.WilliamsTrueSeasonalFC WilliamsTrueSeasonalFC(int lookBack)
		{
			return WilliamsTrueSeasonalFC(Input, lookBack);
		}

		public LW.WilliamsTurtleChannelFC WilliamsTurtleChannelFC()
		{
			return WilliamsTurtleChannelFC(Input);
		}

		public LW.WilliamsWildersVolatilityFC WilliamsWildersVolatilityFC()
		{
			return WilliamsWildersVolatilityFC(Input);
		}

		public LW.WilliamsWillStopFC WilliamsWillStopFC()
		{
			return WilliamsWillStopFC(Input);
		}

		public LW.WilliamsWillValFC WilliamsWillValFC(string symbol, int lookBack)
		{
			return WilliamsWillValFC(Input, symbol, lookBack);
		}


		
		public LW.WilliamsCOTCommercialIndexFC WilliamsCOTCommercialIndexFC(ISeries<double> input, int lookBack)
		{
			if (cacheWilliamsCOTCommercialIndexFC != null)
				for (int idx = 0; idx < cacheWilliamsCOTCommercialIndexFC.Length; idx++)
					if (cacheWilliamsCOTCommercialIndexFC[idx].LookBack == lookBack && cacheWilliamsCOTCommercialIndexFC[idx].EqualsInput(input))
						return cacheWilliamsCOTCommercialIndexFC[idx];
			return CacheIndicator<LW.WilliamsCOTCommercialIndexFC>(new LW.WilliamsCOTCommercialIndexFC(){ LookBack = lookBack }, input, ref cacheWilliamsCOTCommercialIndexFC);
		}

		public LW.WilliamsCOTCommericalNetPositionsFC WilliamsCOTCommericalNetPositionsFC(ISeries<double> input)
		{
			if (cacheWilliamsCOTCommericalNetPositionsFC != null)
				for (int idx = 0; idx < cacheWilliamsCOTCommericalNetPositionsFC.Length; idx++)
					if ( cacheWilliamsCOTCommericalNetPositionsFC[idx].EqualsInput(input))
						return cacheWilliamsCOTCommericalNetPositionsFC[idx];
			return CacheIndicator<LW.WilliamsCOTCommericalNetPositionsFC>(new LW.WilliamsCOTCommericalNetPositionsFC(), input, ref cacheWilliamsCOTCommericalNetPositionsFC);
		}

		public LW.WilliamsCOTLargeSpecIndexFC WilliamsCOTLargeSpecIndexFC(ISeries<double> input, int lookBack)
		{
			if (cacheWilliamsCOTLargeSpecIndexFC != null)
				for (int idx = 0; idx < cacheWilliamsCOTLargeSpecIndexFC.Length; idx++)
					if (cacheWilliamsCOTLargeSpecIndexFC[idx].LookBack == lookBack && cacheWilliamsCOTLargeSpecIndexFC[idx].EqualsInput(input))
						return cacheWilliamsCOTLargeSpecIndexFC[idx];
			return CacheIndicator<LW.WilliamsCOTLargeSpecIndexFC>(new LW.WilliamsCOTLargeSpecIndexFC(){ LookBack = lookBack }, input, ref cacheWilliamsCOTLargeSpecIndexFC);
		}

		public LW.WilliamsCOTLargeSpecNetPositionsFC WilliamsCOTLargeSpecNetPositionsFC(ISeries<double> input)
		{
			if (cacheWilliamsCOTLargeSpecNetPositionsFC != null)
				for (int idx = 0; idx < cacheWilliamsCOTLargeSpecNetPositionsFC.Length; idx++)
					if ( cacheWilliamsCOTLargeSpecNetPositionsFC[idx].EqualsInput(input))
						return cacheWilliamsCOTLargeSpecNetPositionsFC[idx];
			return CacheIndicator<LW.WilliamsCOTLargeSpecNetPositionsFC>(new LW.WilliamsCOTLargeSpecNetPositionsFC(), input, ref cacheWilliamsCOTLargeSpecNetPositionsFC);
		}

		public LW.WilliamsCOTNetPositionsOIFC WilliamsCOTNetPositionsOIFC(ISeries<double> input)
		{
			if (cacheWilliamsCOTNetPositionsOIFC != null)
				for (int idx = 0; idx < cacheWilliamsCOTNetPositionsOIFC.Length; idx++)
					if ( cacheWilliamsCOTNetPositionsOIFC[idx].EqualsInput(input))
						return cacheWilliamsCOTNetPositionsOIFC[idx];
			return CacheIndicator<LW.WilliamsCOTNetPositionsOIFC>(new LW.WilliamsCOTNetPositionsOIFC(), input, ref cacheWilliamsCOTNetPositionsOIFC);
		}

		public LW.WilliamsCOTOpenInterestFC WilliamsCOTOpenInterestFC(ISeries<double> input)
		{
			if (cacheWilliamsCOTOpenInterestFC != null)
				for (int idx = 0; idx < cacheWilliamsCOTOpenInterestFC.Length; idx++)
					if ( cacheWilliamsCOTOpenInterestFC[idx].EqualsInput(input))
						return cacheWilliamsCOTOpenInterestFC[idx];
			return CacheIndicator<LW.WilliamsCOTOpenInterestFC>(new LW.WilliamsCOTOpenInterestFC(), input, ref cacheWilliamsCOTOpenInterestFC);
		}

		public LW.WilliamsCOTSmallSpecIndexFC WilliamsCOTSmallSpecIndexFC(ISeries<double> input, int lookBack)
		{
			if (cacheWilliamsCOTSmallSpecIndexFC != null)
				for (int idx = 0; idx < cacheWilliamsCOTSmallSpecIndexFC.Length; idx++)
					if (cacheWilliamsCOTSmallSpecIndexFC[idx].LookBack == lookBack && cacheWilliamsCOTSmallSpecIndexFC[idx].EqualsInput(input))
						return cacheWilliamsCOTSmallSpecIndexFC[idx];
			return CacheIndicator<LW.WilliamsCOTSmallSpecIndexFC>(new LW.WilliamsCOTSmallSpecIndexFC(){ LookBack = lookBack }, input, ref cacheWilliamsCOTSmallSpecIndexFC);
		}

		public LW.WilliamsCOTSmallSpecNetPositionsFC WilliamsCOTSmallSpecNetPositionsFC(ISeries<double> input)
		{
			if (cacheWilliamsCOTSmallSpecNetPositionsFC != null)
				for (int idx = 0; idx < cacheWilliamsCOTSmallSpecNetPositionsFC.Length; idx++)
					if ( cacheWilliamsCOTSmallSpecNetPositionsFC[idx].EqualsInput(input))
						return cacheWilliamsCOTSmallSpecNetPositionsFC[idx];
			return CacheIndicator<LW.WilliamsCOTSmallSpecNetPositionsFC>(new LW.WilliamsCOTSmallSpecNetPositionsFC(), input, ref cacheWilliamsCOTSmallSpecNetPositionsFC);
		}

		public LW.WilliamsPatternsFC WilliamsPatternsFC(ISeries<double> input)
		{
			if (cacheWilliamsPatternsFC != null)
				for (int idx = 0; idx < cacheWilliamsPatternsFC.Length; idx++)
					if ( cacheWilliamsPatternsFC[idx].EqualsInput(input))
						return cacheWilliamsPatternsFC[idx];
			return CacheIndicator<LW.WilliamsPatternsFC>(new LW.WilliamsPatternsFC(), input, ref cacheWilliamsPatternsFC);
		}

		public LW.WilliamsPaunchIndexFC WilliamsPaunchIndexFC(ISeries<double> input)
		{
			if (cacheWilliamsPaunchIndexFC != null)
				for (int idx = 0; idx < cacheWilliamsPaunchIndexFC.Length; idx++)
					if ( cacheWilliamsPaunchIndexFC[idx].EqualsInput(input))
						return cacheWilliamsPaunchIndexFC[idx];
			return CacheIndicator<LW.WilliamsPaunchIndexFC>(new LW.WilliamsPaunchIndexFC(), input, ref cacheWilliamsPaunchIndexFC);
		}

		public LW.WilliamsPctRFC WilliamsPctRFC(ISeries<double> input, int period)
		{
			if (cacheWilliamsPctRFC != null)
				for (int idx = 0; idx < cacheWilliamsPctRFC.Length; idx++)
					if (cacheWilliamsPctRFC[idx].Period == period && cacheWilliamsPctRFC[idx].EqualsInput(input))
						return cacheWilliamsPctRFC[idx];
			return CacheIndicator<LW.WilliamsPctRFC>(new LW.WilliamsPctRFC(){ Period = period }, input, ref cacheWilliamsPctRFC);
		}

		public LW.WilliamsPOIVFC WilliamsPOIVFC(ISeries<double> input)
		{
			if (cacheWilliamsPOIVFC != null)
				for (int idx = 0; idx < cacheWilliamsPOIVFC.Length; idx++)
					if ( cacheWilliamsPOIVFC[idx].EqualsInput(input))
						return cacheWilliamsPOIVFC[idx];
			return CacheIndicator<LW.WilliamsPOIVFC>(new LW.WilliamsPOIVFC(), input, ref cacheWilliamsPOIVFC);
		}

		public LW.WilliamsProGoProfessionalFC WilliamsProGoProfessionalFC(ISeries<double> input)
		{
			if (cacheWilliamsProGoProfessionalFC != null)
				for (int idx = 0; idx < cacheWilliamsProGoProfessionalFC.Length; idx++)
					if ( cacheWilliamsProGoProfessionalFC[idx].EqualsInput(input))
						return cacheWilliamsProGoProfessionalFC[idx];
			return CacheIndicator<LW.WilliamsProGoProfessionalFC>(new LW.WilliamsProGoProfessionalFC(), input, ref cacheWilliamsProGoProfessionalFC);
		}

		public LW.WilliamsProGoPublicFC WilliamsProGoPublicFC(ISeries<double> input)
		{
			if (cacheWilliamsProGoPublicFC != null)
				for (int idx = 0; idx < cacheWilliamsProGoPublicFC.Length; idx++)
					if ( cacheWilliamsProGoPublicFC[idx].EqualsInput(input))
						return cacheWilliamsProGoPublicFC[idx];
			return CacheIndicator<LW.WilliamsProGoPublicFC>(new LW.WilliamsProGoPublicFC(), input, ref cacheWilliamsProGoPublicFC);
		}

		public LW.WilliamsSentimentIndexFC WilliamsSentimentIndexFC(ISeries<double> input)
		{
			if (cacheWilliamsSentimentIndexFC != null)
				for (int idx = 0; idx < cacheWilliamsSentimentIndexFC.Length; idx++)
					if ( cacheWilliamsSentimentIndexFC[idx].EqualsInput(input))
						return cacheWilliamsSentimentIndexFC[idx];
			return CacheIndicator<LW.WilliamsSentimentIndexFC>(new LW.WilliamsSentimentIndexFC(), input, ref cacheWilliamsSentimentIndexFC);
		}

		public LW.WilliamsSpreadDifferenceFC WilliamsSpreadDifferenceFC(ISeries<double> input)
		{
			if (cacheWilliamsSpreadDifferenceFC != null)
				for (int idx = 0; idx < cacheWilliamsSpreadDifferenceFC.Length; idx++)
					if ( cacheWilliamsSpreadDifferenceFC[idx].EqualsInput(input))
						return cacheWilliamsSpreadDifferenceFC[idx];
			return CacheIndicator<LW.WilliamsSpreadDifferenceFC>(new LW.WilliamsSpreadDifferenceFC(), input, ref cacheWilliamsSpreadDifferenceFC);
		}

		public LW.WilliamsTargetShooter3 WilliamsTargetShooter3(ISeries<double> input, int extendTargetBars)
		{
			if (cacheWilliamsTargetShooter3 != null)
				for (int idx = 0; idx < cacheWilliamsTargetShooter3.Length; idx++)
					if (cacheWilliamsTargetShooter3[idx].ExtendTargetBars == extendTargetBars && cacheWilliamsTargetShooter3[idx].EqualsInput(input))
						return cacheWilliamsTargetShooter3[idx];
			return CacheIndicator<LW.WilliamsTargetShooter3>(new LW.WilliamsTargetShooter3(){ ExtendTargetBars = extendTargetBars }, input, ref cacheWilliamsTargetShooter3);
		}

		public LW.WilliamsTrueHigh WilliamsTrueHigh(ISeries<double> input)
		{
			if (cacheWilliamsTrueHigh != null)
				for (int idx = 0; idx < cacheWilliamsTrueHigh.Length; idx++)
					if ( cacheWilliamsTrueHigh[idx].EqualsInput(input))
						return cacheWilliamsTrueHigh[idx];
			return CacheIndicator<LW.WilliamsTrueHigh>(new LW.WilliamsTrueHigh(), input, ref cacheWilliamsTrueHigh);
		}

		public LW.WilliamsTrueLow WilliamsTrueLow(ISeries<double> input)
		{
			if (cacheWilliamsTrueLow != null)
				for (int idx = 0; idx < cacheWilliamsTrueLow.Length; idx++)
					if ( cacheWilliamsTrueLow[idx].EqualsInput(input))
						return cacheWilliamsTrueLow[idx];
			return CacheIndicator<LW.WilliamsTrueLow>(new LW.WilliamsTrueLow(), input, ref cacheWilliamsTrueLow);
		}

		public LW.WilliamsTrueRangeFC WilliamsTrueRangeFC(ISeries<double> input)
		{
			if (cacheWilliamsTrueRangeFC != null)
				for (int idx = 0; idx < cacheWilliamsTrueRangeFC.Length; idx++)
					if ( cacheWilliamsTrueRangeFC[idx].EqualsInput(input))
						return cacheWilliamsTrueRangeFC[idx];
			return CacheIndicator<LW.WilliamsTrueRangeFC>(new LW.WilliamsTrueRangeFC(), input, ref cacheWilliamsTrueRangeFC);
		}

		public LW.WilliamsTrueSeasonalFC WilliamsTrueSeasonalFC(ISeries<double> input, int lookBack)
		{
			if (cacheWilliamsTrueSeasonalFC != null)
				for (int idx = 0; idx < cacheWilliamsTrueSeasonalFC.Length; idx++)
					if (cacheWilliamsTrueSeasonalFC[idx].LookBack == lookBack && cacheWilliamsTrueSeasonalFC[idx].EqualsInput(input))
						return cacheWilliamsTrueSeasonalFC[idx];
			return CacheIndicator<LW.WilliamsTrueSeasonalFC>(new LW.WilliamsTrueSeasonalFC(){ LookBack = lookBack }, input, ref cacheWilliamsTrueSeasonalFC);
		}

		public LW.WilliamsTurtleChannelFC WilliamsTurtleChannelFC(ISeries<double> input)
		{
			if (cacheWilliamsTurtleChannelFC != null)
				for (int idx = 0; idx < cacheWilliamsTurtleChannelFC.Length; idx++)
					if ( cacheWilliamsTurtleChannelFC[idx].EqualsInput(input))
						return cacheWilliamsTurtleChannelFC[idx];
			return CacheIndicator<LW.WilliamsTurtleChannelFC>(new LW.WilliamsTurtleChannelFC(), input, ref cacheWilliamsTurtleChannelFC);
		}

		public LW.WilliamsWildersVolatilityFC WilliamsWildersVolatilityFC(ISeries<double> input)
		{
			if (cacheWilliamsWildersVolatilityFC != null)
				for (int idx = 0; idx < cacheWilliamsWildersVolatilityFC.Length; idx++)
					if ( cacheWilliamsWildersVolatilityFC[idx].EqualsInput(input))
						return cacheWilliamsWildersVolatilityFC[idx];
			return CacheIndicator<LW.WilliamsWildersVolatilityFC>(new LW.WilliamsWildersVolatilityFC(), input, ref cacheWilliamsWildersVolatilityFC);
		}

		public LW.WilliamsWillStopFC WilliamsWillStopFC(ISeries<double> input)
		{
			if (cacheWilliamsWillStopFC != null)
				for (int idx = 0; idx < cacheWilliamsWillStopFC.Length; idx++)
					if ( cacheWilliamsWillStopFC[idx].EqualsInput(input))
						return cacheWilliamsWillStopFC[idx];
			return CacheIndicator<LW.WilliamsWillStopFC>(new LW.WilliamsWillStopFC(), input, ref cacheWilliamsWillStopFC);
		}

		public LW.WilliamsWillValFC WilliamsWillValFC(ISeries<double> input, string symbol, int lookBack)
		{
			if (cacheWilliamsWillValFC != null)
				for (int idx = 0; idx < cacheWilliamsWillValFC.Length; idx++)
					if (cacheWilliamsWillValFC[idx].Symbol == symbol && cacheWilliamsWillValFC[idx].LookBack == lookBack && cacheWilliamsWillValFC[idx].EqualsInput(input))
						return cacheWilliamsWillValFC[idx];
			return CacheIndicator<LW.WilliamsWillValFC>(new LW.WilliamsWillValFC(){ Symbol = symbol, LookBack = lookBack }, input, ref cacheWilliamsWillValFC);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.LW.WilliamsCOTCommercialIndexFC WilliamsCOTCommercialIndexFC(int lookBack)
		{
			return indicator.WilliamsCOTCommercialIndexFC(Input, lookBack);
		}

		public Indicators.LW.WilliamsCOTCommericalNetPositionsFC WilliamsCOTCommericalNetPositionsFC()
		{
			return indicator.WilliamsCOTCommericalNetPositionsFC(Input);
		}

		public Indicators.LW.WilliamsCOTLargeSpecIndexFC WilliamsCOTLargeSpecIndexFC(int lookBack)
		{
			return indicator.WilliamsCOTLargeSpecIndexFC(Input, lookBack);
		}

		public Indicators.LW.WilliamsCOTLargeSpecNetPositionsFC WilliamsCOTLargeSpecNetPositionsFC()
		{
			return indicator.WilliamsCOTLargeSpecNetPositionsFC(Input);
		}

		public Indicators.LW.WilliamsCOTNetPositionsOIFC WilliamsCOTNetPositionsOIFC()
		{
			return indicator.WilliamsCOTNetPositionsOIFC(Input);
		}

		public Indicators.LW.WilliamsCOTOpenInterestFC WilliamsCOTOpenInterestFC()
		{
			return indicator.WilliamsCOTOpenInterestFC(Input);
		}

		public Indicators.LW.WilliamsCOTSmallSpecIndexFC WilliamsCOTSmallSpecIndexFC(int lookBack)
		{
			return indicator.WilliamsCOTSmallSpecIndexFC(Input, lookBack);
		}

		public Indicators.LW.WilliamsCOTSmallSpecNetPositionsFC WilliamsCOTSmallSpecNetPositionsFC()
		{
			return indicator.WilliamsCOTSmallSpecNetPositionsFC(Input);
		}

		public Indicators.LW.WilliamsPatternsFC WilliamsPatternsFC()
		{
			return indicator.WilliamsPatternsFC(Input);
		}

		public Indicators.LW.WilliamsPaunchIndexFC WilliamsPaunchIndexFC()
		{
			return indicator.WilliamsPaunchIndexFC(Input);
		}

		public Indicators.LW.WilliamsPctRFC WilliamsPctRFC(int period)
		{
			return indicator.WilliamsPctRFC(Input, period);
		}

		public Indicators.LW.WilliamsPOIVFC WilliamsPOIVFC()
		{
			return indicator.WilliamsPOIVFC(Input);
		}

		public Indicators.LW.WilliamsProGoProfessionalFC WilliamsProGoProfessionalFC()
		{
			return indicator.WilliamsProGoProfessionalFC(Input);
		}

		public Indicators.LW.WilliamsProGoPublicFC WilliamsProGoPublicFC()
		{
			return indicator.WilliamsProGoPublicFC(Input);
		}

		public Indicators.LW.WilliamsSentimentIndexFC WilliamsSentimentIndexFC()
		{
			return indicator.WilliamsSentimentIndexFC(Input);
		}

		public Indicators.LW.WilliamsSpreadDifferenceFC WilliamsSpreadDifferenceFC()
		{
			return indicator.WilliamsSpreadDifferenceFC(Input);
		}

		public Indicators.LW.WilliamsTargetShooter3 WilliamsTargetShooter3(int extendTargetBars)
		{
			return indicator.WilliamsTargetShooter3(Input, extendTargetBars);
		}

		public Indicators.LW.WilliamsTrueHigh WilliamsTrueHigh()
		{
			return indicator.WilliamsTrueHigh(Input);
		}

		public Indicators.LW.WilliamsTrueLow WilliamsTrueLow()
		{
			return indicator.WilliamsTrueLow(Input);
		}

		public Indicators.LW.WilliamsTrueRangeFC WilliamsTrueRangeFC()
		{
			return indicator.WilliamsTrueRangeFC(Input);
		}

		public Indicators.LW.WilliamsTrueSeasonalFC WilliamsTrueSeasonalFC(int lookBack)
		{
			return indicator.WilliamsTrueSeasonalFC(Input, lookBack);
		}

		public Indicators.LW.WilliamsTurtleChannelFC WilliamsTurtleChannelFC()
		{
			return indicator.WilliamsTurtleChannelFC(Input);
		}

		public Indicators.LW.WilliamsWildersVolatilityFC WilliamsWildersVolatilityFC()
		{
			return indicator.WilliamsWildersVolatilityFC(Input);
		}

		public Indicators.LW.WilliamsWillStopFC WilliamsWillStopFC()
		{
			return indicator.WilliamsWillStopFC(Input);
		}

		public Indicators.LW.WilliamsWillValFC WilliamsWillValFC(string symbol, int lookBack)
		{
			return indicator.WilliamsWillValFC(Input, symbol, lookBack);
		}


		
		public Indicators.LW.WilliamsCOTCommercialIndexFC WilliamsCOTCommercialIndexFC(ISeries<double> input , int lookBack)
		{
			return indicator.WilliamsCOTCommercialIndexFC(input, lookBack);
		}

		public Indicators.LW.WilliamsCOTCommericalNetPositionsFC WilliamsCOTCommericalNetPositionsFC(ISeries<double> input )
		{
			return indicator.WilliamsCOTCommericalNetPositionsFC(input);
		}

		public Indicators.LW.WilliamsCOTLargeSpecIndexFC WilliamsCOTLargeSpecIndexFC(ISeries<double> input , int lookBack)
		{
			return indicator.WilliamsCOTLargeSpecIndexFC(input, lookBack);
		}

		public Indicators.LW.WilliamsCOTLargeSpecNetPositionsFC WilliamsCOTLargeSpecNetPositionsFC(ISeries<double> input )
		{
			return indicator.WilliamsCOTLargeSpecNetPositionsFC(input);
		}

		public Indicators.LW.WilliamsCOTNetPositionsOIFC WilliamsCOTNetPositionsOIFC(ISeries<double> input )
		{
			return indicator.WilliamsCOTNetPositionsOIFC(input);
		}

		public Indicators.LW.WilliamsCOTOpenInterestFC WilliamsCOTOpenInterestFC(ISeries<double> input )
		{
			return indicator.WilliamsCOTOpenInterestFC(input);
		}

		public Indicators.LW.WilliamsCOTSmallSpecIndexFC WilliamsCOTSmallSpecIndexFC(ISeries<double> input , int lookBack)
		{
			return indicator.WilliamsCOTSmallSpecIndexFC(input, lookBack);
		}

		public Indicators.LW.WilliamsCOTSmallSpecNetPositionsFC WilliamsCOTSmallSpecNetPositionsFC(ISeries<double> input )
		{
			return indicator.WilliamsCOTSmallSpecNetPositionsFC(input);
		}

		public Indicators.LW.WilliamsPatternsFC WilliamsPatternsFC(ISeries<double> input )
		{
			return indicator.WilliamsPatternsFC(input);
		}

		public Indicators.LW.WilliamsPaunchIndexFC WilliamsPaunchIndexFC(ISeries<double> input )
		{
			return indicator.WilliamsPaunchIndexFC(input);
		}

		public Indicators.LW.WilliamsPctRFC WilliamsPctRFC(ISeries<double> input , int period)
		{
			return indicator.WilliamsPctRFC(input, period);
		}

		public Indicators.LW.WilliamsPOIVFC WilliamsPOIVFC(ISeries<double> input )
		{
			return indicator.WilliamsPOIVFC(input);
		}

		public Indicators.LW.WilliamsProGoProfessionalFC WilliamsProGoProfessionalFC(ISeries<double> input )
		{
			return indicator.WilliamsProGoProfessionalFC(input);
		}

		public Indicators.LW.WilliamsProGoPublicFC WilliamsProGoPublicFC(ISeries<double> input )
		{
			return indicator.WilliamsProGoPublicFC(input);
		}

		public Indicators.LW.WilliamsSentimentIndexFC WilliamsSentimentIndexFC(ISeries<double> input )
		{
			return indicator.WilliamsSentimentIndexFC(input);
		}

		public Indicators.LW.WilliamsSpreadDifferenceFC WilliamsSpreadDifferenceFC(ISeries<double> input )
		{
			return indicator.WilliamsSpreadDifferenceFC(input);
		}

		public Indicators.LW.WilliamsTargetShooter3 WilliamsTargetShooter3(ISeries<double> input , int extendTargetBars)
		{
			return indicator.WilliamsTargetShooter3(input, extendTargetBars);
		}

		public Indicators.LW.WilliamsTrueHigh WilliamsTrueHigh(ISeries<double> input )
		{
			return indicator.WilliamsTrueHigh(input);
		}

		public Indicators.LW.WilliamsTrueLow WilliamsTrueLow(ISeries<double> input )
		{
			return indicator.WilliamsTrueLow(input);
		}

		public Indicators.LW.WilliamsTrueRangeFC WilliamsTrueRangeFC(ISeries<double> input )
		{
			return indicator.WilliamsTrueRangeFC(input);
		}

		public Indicators.LW.WilliamsTrueSeasonalFC WilliamsTrueSeasonalFC(ISeries<double> input , int lookBack)
		{
			return indicator.WilliamsTrueSeasonalFC(input, lookBack);
		}

		public Indicators.LW.WilliamsTurtleChannelFC WilliamsTurtleChannelFC(ISeries<double> input )
		{
			return indicator.WilliamsTurtleChannelFC(input);
		}

		public Indicators.LW.WilliamsWildersVolatilityFC WilliamsWildersVolatilityFC(ISeries<double> input )
		{
			return indicator.WilliamsWildersVolatilityFC(input);
		}

		public Indicators.LW.WilliamsWillStopFC WilliamsWillStopFC(ISeries<double> input )
		{
			return indicator.WilliamsWillStopFC(input);
		}

		public Indicators.LW.WilliamsWillValFC WilliamsWillValFC(ISeries<double> input , string symbol, int lookBack)
		{
			return indicator.WilliamsWillValFC(input, symbol, lookBack);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.LW.WilliamsCOTCommercialIndexFC WilliamsCOTCommercialIndexFC(int lookBack)
		{
			return indicator.WilliamsCOTCommercialIndexFC(Input, lookBack);
		}

		public Indicators.LW.WilliamsCOTCommericalNetPositionsFC WilliamsCOTCommericalNetPositionsFC()
		{
			return indicator.WilliamsCOTCommericalNetPositionsFC(Input);
		}

		public Indicators.LW.WilliamsCOTLargeSpecIndexFC WilliamsCOTLargeSpecIndexFC(int lookBack)
		{
			return indicator.WilliamsCOTLargeSpecIndexFC(Input, lookBack);
		}

		public Indicators.LW.WilliamsCOTLargeSpecNetPositionsFC WilliamsCOTLargeSpecNetPositionsFC()
		{
			return indicator.WilliamsCOTLargeSpecNetPositionsFC(Input);
		}

		public Indicators.LW.WilliamsCOTNetPositionsOIFC WilliamsCOTNetPositionsOIFC()
		{
			return indicator.WilliamsCOTNetPositionsOIFC(Input);
		}

		public Indicators.LW.WilliamsCOTOpenInterestFC WilliamsCOTOpenInterestFC()
		{
			return indicator.WilliamsCOTOpenInterestFC(Input);
		}

		public Indicators.LW.WilliamsCOTSmallSpecIndexFC WilliamsCOTSmallSpecIndexFC(int lookBack)
		{
			return indicator.WilliamsCOTSmallSpecIndexFC(Input, lookBack);
		}

		public Indicators.LW.WilliamsCOTSmallSpecNetPositionsFC WilliamsCOTSmallSpecNetPositionsFC()
		{
			return indicator.WilliamsCOTSmallSpecNetPositionsFC(Input);
		}

		public Indicators.LW.WilliamsPatternsFC WilliamsPatternsFC()
		{
			return indicator.WilliamsPatternsFC(Input);
		}

		public Indicators.LW.WilliamsPaunchIndexFC WilliamsPaunchIndexFC()
		{
			return indicator.WilliamsPaunchIndexFC(Input);
		}

		public Indicators.LW.WilliamsPctRFC WilliamsPctRFC(int period)
		{
			return indicator.WilliamsPctRFC(Input, period);
		}

		public Indicators.LW.WilliamsPOIVFC WilliamsPOIVFC()
		{
			return indicator.WilliamsPOIVFC(Input);
		}

		public Indicators.LW.WilliamsProGoProfessionalFC WilliamsProGoProfessionalFC()
		{
			return indicator.WilliamsProGoProfessionalFC(Input);
		}

		public Indicators.LW.WilliamsProGoPublicFC WilliamsProGoPublicFC()
		{
			return indicator.WilliamsProGoPublicFC(Input);
		}

		public Indicators.LW.WilliamsSentimentIndexFC WilliamsSentimentIndexFC()
		{
			return indicator.WilliamsSentimentIndexFC(Input);
		}

		public Indicators.LW.WilliamsSpreadDifferenceFC WilliamsSpreadDifferenceFC()
		{
			return indicator.WilliamsSpreadDifferenceFC(Input);
		}

		public Indicators.LW.WilliamsTargetShooter3 WilliamsTargetShooter3(int extendTargetBars)
		{
			return indicator.WilliamsTargetShooter3(Input, extendTargetBars);
		}

		public Indicators.LW.WilliamsTrueHigh WilliamsTrueHigh()
		{
			return indicator.WilliamsTrueHigh(Input);
		}

		public Indicators.LW.WilliamsTrueLow WilliamsTrueLow()
		{
			return indicator.WilliamsTrueLow(Input);
		}

		public Indicators.LW.WilliamsTrueRangeFC WilliamsTrueRangeFC()
		{
			return indicator.WilliamsTrueRangeFC(Input);
		}

		public Indicators.LW.WilliamsTrueSeasonalFC WilliamsTrueSeasonalFC(int lookBack)
		{
			return indicator.WilliamsTrueSeasonalFC(Input, lookBack);
		}

		public Indicators.LW.WilliamsTurtleChannelFC WilliamsTurtleChannelFC()
		{
			return indicator.WilliamsTurtleChannelFC(Input);
		}

		public Indicators.LW.WilliamsWildersVolatilityFC WilliamsWildersVolatilityFC()
		{
			return indicator.WilliamsWildersVolatilityFC(Input);
		}

		public Indicators.LW.WilliamsWillStopFC WilliamsWillStopFC()
		{
			return indicator.WilliamsWillStopFC(Input);
		}

		public Indicators.LW.WilliamsWillValFC WilliamsWillValFC(string symbol, int lookBack)
		{
			return indicator.WilliamsWillValFC(Input, symbol, lookBack);
		}


		
		public Indicators.LW.WilliamsCOTCommercialIndexFC WilliamsCOTCommercialIndexFC(ISeries<double> input , int lookBack)
		{
			return indicator.WilliamsCOTCommercialIndexFC(input, lookBack);
		}

		public Indicators.LW.WilliamsCOTCommericalNetPositionsFC WilliamsCOTCommericalNetPositionsFC(ISeries<double> input )
		{
			return indicator.WilliamsCOTCommericalNetPositionsFC(input);
		}

		public Indicators.LW.WilliamsCOTLargeSpecIndexFC WilliamsCOTLargeSpecIndexFC(ISeries<double> input , int lookBack)
		{
			return indicator.WilliamsCOTLargeSpecIndexFC(input, lookBack);
		}

		public Indicators.LW.WilliamsCOTLargeSpecNetPositionsFC WilliamsCOTLargeSpecNetPositionsFC(ISeries<double> input )
		{
			return indicator.WilliamsCOTLargeSpecNetPositionsFC(input);
		}

		public Indicators.LW.WilliamsCOTNetPositionsOIFC WilliamsCOTNetPositionsOIFC(ISeries<double> input )
		{
			return indicator.WilliamsCOTNetPositionsOIFC(input);
		}

		public Indicators.LW.WilliamsCOTOpenInterestFC WilliamsCOTOpenInterestFC(ISeries<double> input )
		{
			return indicator.WilliamsCOTOpenInterestFC(input);
		}

		public Indicators.LW.WilliamsCOTSmallSpecIndexFC WilliamsCOTSmallSpecIndexFC(ISeries<double> input , int lookBack)
		{
			return indicator.WilliamsCOTSmallSpecIndexFC(input, lookBack);
		}

		public Indicators.LW.WilliamsCOTSmallSpecNetPositionsFC WilliamsCOTSmallSpecNetPositionsFC(ISeries<double> input )
		{
			return indicator.WilliamsCOTSmallSpecNetPositionsFC(input);
		}

		public Indicators.LW.WilliamsPatternsFC WilliamsPatternsFC(ISeries<double> input )
		{
			return indicator.WilliamsPatternsFC(input);
		}

		public Indicators.LW.WilliamsPaunchIndexFC WilliamsPaunchIndexFC(ISeries<double> input )
		{
			return indicator.WilliamsPaunchIndexFC(input);
		}

		public Indicators.LW.WilliamsPctRFC WilliamsPctRFC(ISeries<double> input , int period)
		{
			return indicator.WilliamsPctRFC(input, period);
		}

		public Indicators.LW.WilliamsPOIVFC WilliamsPOIVFC(ISeries<double> input )
		{
			return indicator.WilliamsPOIVFC(input);
		}

		public Indicators.LW.WilliamsProGoProfessionalFC WilliamsProGoProfessionalFC(ISeries<double> input )
		{
			return indicator.WilliamsProGoProfessionalFC(input);
		}

		public Indicators.LW.WilliamsProGoPublicFC WilliamsProGoPublicFC(ISeries<double> input )
		{
			return indicator.WilliamsProGoPublicFC(input);
		}

		public Indicators.LW.WilliamsSentimentIndexFC WilliamsSentimentIndexFC(ISeries<double> input )
		{
			return indicator.WilliamsSentimentIndexFC(input);
		}

		public Indicators.LW.WilliamsSpreadDifferenceFC WilliamsSpreadDifferenceFC(ISeries<double> input )
		{
			return indicator.WilliamsSpreadDifferenceFC(input);
		}

		public Indicators.LW.WilliamsTargetShooter3 WilliamsTargetShooter3(ISeries<double> input , int extendTargetBars)
		{
			return indicator.WilliamsTargetShooter3(input, extendTargetBars);
		}

		public Indicators.LW.WilliamsTrueHigh WilliamsTrueHigh(ISeries<double> input )
		{
			return indicator.WilliamsTrueHigh(input);
		}

		public Indicators.LW.WilliamsTrueLow WilliamsTrueLow(ISeries<double> input )
		{
			return indicator.WilliamsTrueLow(input);
		}

		public Indicators.LW.WilliamsTrueRangeFC WilliamsTrueRangeFC(ISeries<double> input )
		{
			return indicator.WilliamsTrueRangeFC(input);
		}

		public Indicators.LW.WilliamsTrueSeasonalFC WilliamsTrueSeasonalFC(ISeries<double> input , int lookBack)
		{
			return indicator.WilliamsTrueSeasonalFC(input, lookBack);
		}

		public Indicators.LW.WilliamsTurtleChannelFC WilliamsTurtleChannelFC(ISeries<double> input )
		{
			return indicator.WilliamsTurtleChannelFC(input);
		}

		public Indicators.LW.WilliamsWildersVolatilityFC WilliamsWildersVolatilityFC(ISeries<double> input )
		{
			return indicator.WilliamsWildersVolatilityFC(input);
		}

		public Indicators.LW.WilliamsWillStopFC WilliamsWillStopFC(ISeries<double> input )
		{
			return indicator.WilliamsWillStopFC(input);
		}

		public Indicators.LW.WilliamsWillValFC WilliamsWillValFC(ISeries<double> input , string symbol, int lookBack)
		{
			return indicator.WilliamsWillValFC(input, symbol, lookBack);
		}

	}
}

#endregion
