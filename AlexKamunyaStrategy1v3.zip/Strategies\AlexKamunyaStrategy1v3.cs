#region Using declarations
using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators.GB;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
using System.IO;
#endregion

namespace NinjaTrader.NinjaScript.Strategies{
	[Gui.CategoryOrder(par1, 	1)]
	[Gui.CategoryOrder(par2_1, 	2)]
	[Gui.CategoryOrder(par2_2, 	3)]
	[Gui.CategoryOrder(par3, 	4)]
	
	public class AlexKamunyaStrategy1v3 : Strategy{
		
		#region Class attributes
		
		SignalHandler 	glSignalHandler;
		
		FilterMarketPositionSignal	glFilterMarketPositionSignal;
		EntrySupDemFibChangesSignal	glEntrySupDemFibChangesSignal;
		CalculateEntryZzTrendChangedSignal	glCalculateEntryZzTrendChangedSignal;
		CalculateExitZzTrendChangedSignal	glCalculateExitZzTrendChangedSignal;
		
		SMA					glSMA;
		gbChandelierStop	glGbChandelierStop;
		
		Zigzag				glZigZagEntry;
		Zigzag				glZigZagExit;
		
		bool				glNewBar;
		DateTime			glNewBarTime;
		
		int					glPrevTrendEntry;
		int					glPrevTrendExit;
		
		List<Order> 		glOrders;
		List<Order> 		glOrdersTargets;
		
		string				glOrderNameLong		= "Long";
		string				glOrderNameShort	= "Short";

		
		#endregion
		
		#region System
		protected override void OnStateChange(){
			if (State == State.SetDefaults){
				Description									= @"Enter the description for your new custom Strategy here.";
				Name										= "AlexKamunyaStrategy1v3";
				Calculate									= Calculate.OnEachTick;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= false;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= true;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 0;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				IsUnmanaged									= true;
				
				pmEnableLog									= true;
				pmLot 										= 1;
				
				pmEnableTrendFilter							= true;
				pmTrendFilterTicksOffset					= 0;
				
				pmDirectionType								= EnumDirectionType.Both;
				
				
				pmTakeProfit								= 20;
				
				pmStopLossType								= EnumStopLossType.StopLossTypeHardTicks;
				pmStopLoss									= 24;
				pmStopLossOffset							= 10;
				
				pmSdfen_Calculate							= Calculate.OnBarClose;
				pmSdfen_percentamount						= .01;
				pmSdfen_revAmount							= .15;
				pmSdfen_atrreversal							= 1.0;
				pmSdfen_atrlength							= 5;
				
				pmSdfex_Calculate							= Calculate.OnBarClose;
				pmSdfex_percentamount						= .01;
				pmSdfex_revAmount							= .15;
				pmSdfex_atrreversal							= 1.0;
				pmSdfex_atrlength							= 5;
				
				
				pmGcsLookback								= 22;
				pmGcsMultipleATR							= 3;
				pmGcsUseTicks								= false;
				pmGcsNbrOfTicks								= 30;
				pmGcsColorBG								= true;
///
				
				
				AddPlot(new Stroke(Brushes.Transparent, 1),	PlotStyle.Dot, "Entry: Trend");
				AddPlot(new Stroke(Brushes.Transparent, 1),	PlotStyle.Dot, "Exit: Trend");
				
				AddPlot(new Stroke(Brushes.Transparent, 1),	PlotStyle.Dot, "Entry: LastDnTrend");
				AddPlot(new Stroke(Brushes.Transparent, 1),	PlotStyle.Dot, "Entry: LastUpTrend");
				
				AddPlot(new Stroke(Brushes.Transparent, 1),	PlotStyle.Dot, "Exit: LastDnTrend");
				AddPlot(new Stroke(Brushes.Transparent, 1),	PlotStyle.Dot, "Exit: LastUpTrend");
			}
			else if (State == State.Configure){
			}
			else if (State == State.DataLoaded){
				
				glZigZagEntry	= new Zigzag(this);
				glZigZagExit	= new Zigzag(this);
				
				glGbChandelierStop	= gbChandelierStop(pmGcsLookback,pmGcsMultipleATR,pmGcsUseTicks,pmGcsNbrOfTicks, pmGcsColorBG);
				glGbChandelierStop.DisplayInDataBox	= true;
				AddChartIndicator(glGbChandelierStop);
								
				
				glFilterMarketPositionSignal			= new FilterMarketPositionSignal(this);
				glEntrySupDemFibChangesSignal			= new EntrySupDemFibChangesSignal(this);
				glCalculateEntryZzTrendChangedSignal	= new CalculateEntryZzTrendChangedSignal(this);
				glCalculateExitZzTrendChangedSignal		= new CalculateExitZzTrendChangedSignal(this);
				
				glSignalHandler = new SignalHandler(this,"SH_Main");
				glSignalHandler.AddSignal(new FilterTradeDirectionSignal(this));
				glSignalHandler.AddSignal(new FilterMarketPositionSignal(this));
				glSignalHandler.AddSignal(glCalculateEntryZzTrendChangedSignal);
				glSignalHandler.AddSignal(glCalculateExitZzTrendChangedSignal);
				glSignalHandler.AddSignal(glEntrySupDemFibChangesSignal);
				if (pmEnableTrendFilter){
					glSignalHandler.AddSignal(new FilterGbChandelierStopIndicatorSignal(this));
					if (pmTrendFilterTicksOffset > 0){
						glSignalHandler.AddSignal(new FilterGbChandelierStopIndicatorTickOffsetSignal(this));
					}
				}
				
			}
			else if (State == State.Terminated){
			}
			else if (State == State.Realtime){
				if (glOrders != null){
					for (int i = 0; i < glOrders.Count; i++){
						if (glOrders[i] != null && !OrderIsInactive(glOrders[i])) glOrders[i] = GetRealtimeOrder(glOrders[i]);
					}
				}
				if (glOrdersTargets != null){
					for (int i = 0; i < glOrdersTargets.Count; i++){
						if (glOrdersTargets[i] != null && !OrderIsInactive(glOrdersTargets[i])) glOrdersTargets[i] = GetRealtimeOrder(glOrdersTargets[i]);
					}
				}
			}
		}
		
		protected override void OnBarUpdate(){
			if (
				CurrentBars[0] < 1
				) return;
			
			NewBar();
			
			ZigZagActions();
			
			if (State != State.Historical){
				if (!glFilterMarketPositionSignal.sPositionLock){
					ActionMain();
				}
			}
		}
		
		void ZigZagActions(){
			OnBarUpdateSupplyDemandFibExtensionsEntry();
			OnBarUpdateSupplyDemandFibExtensionsExit();
		}
		
		
		void ActionMain(){
			SignalHandler	sh	= glSignalHandler;
			
			sh.OnTick();
			SignalType openSignal = sh.GetOpenSignal();
			SignalType closeSignal = sh.GetCloseSignal();
			
			if (glNewBar){
				sh.LogOpenSignal();
				sh.LogCloseSignal();
			}
			
			MarketPosition pos = Position.MarketPosition;
			
			if (openSignal != NO && (pmSdfen_Calculate == Calculate.OnBarClose ? glNewBar : true)){
				if (!glNewBar){
					sh.LogOpenSignal();
					sh.LogCloseSignal();
				}
				
				CancelAllEntryOrders();
				CancelAllTragetOrders();
				
				switch (openSignal){
					case BUY: 	
						if (pos == MarketPosition.Short)
							SubmitOrderUnmanaged(BarsInProgress, OrderAction.BuyToCover, OrderType.Market, Position.Quantity, 0, 0, "", "Exit on opposite signal");
						glOrders	= new List<Order>();
						glOrders.Add(SubmitOrderUnmanaged(BarsInProgress, OrderAction.Buy, OrderType.Market, pmLot, 0, 0, "", glOrderNameLong));
						break;
					case SELL: 	
						if (pos == MarketPosition.Long)
							SubmitOrderUnmanaged(BarsInProgress, OrderAction.Sell, OrderType.Market, Position.Quantity, 0, 0, "", "Exit on opposite signal");
						glOrders	= new List<Order>();
						glOrders.Add(SubmitOrderUnmanaged(BarsInProgress, OrderAction.SellShort, OrderType.Market, pmLot, 0, 0, "", glOrderNameShort));
						break;
				}
				
			}
			else if (closeSignal != NO && (pmSdfex_Calculate == Calculate.OnBarClose ? glNewBar : true)){
				bool	check	= false;
				
				if (closeSignal != BUY && pos == MarketPosition.Long && !glFilterMarketPositionSignal.sPositionLock){
					CancelAllEntryOrders();
					CancelAllTragetOrders();
					check	= true;
					glFilterMarketPositionSignal.UpdateLock(true,"ActionExit:closeSignal != BUY:");
					SubmitOrderUnmanaged(BarsInProgress, OrderAction.Sell, OrderType.Market, Position.Quantity, 0, 0, "", "Exit on closing signal");
				}
				if (closeSignal != SELL && pos == MarketPosition.Short && !glFilterMarketPositionSignal.sPositionLock){
					CancelAllEntryOrders();
					CancelAllTragetOrders();
					check	= true;
					glFilterMarketPositionSignal.UpdateLock(true,"ActionExit:closeSignal != SELL:");
					SubmitOrderUnmanaged(BarsInProgress, OrderAction.BuyToCover, OrderType.Market, Position.Quantity, 0, 0, "", "Exit on closing signal");
				}
				
				if (check && !glNewBar){
					sh.LogOpenSignal();
					sh.LogCloseSignal();
				}
			}
		}
		
		void OnBarUpdateSupplyDemandFibExtensionsEntry() {
			glZigZagEntry.ZigZagUpdate(
										CurrentBars[0],
										Highs[0],
										Lows[0],
										pmSdfen_percentamount,
										pmSdfen_revAmount,
										pmSdfen_atrlength,
										pmSdfen_atrreversal,
										10,
										ATRWilders(pmSdfen_atrlength)[0],
										Closes[0][0]
										);
			
			int 	zz	=	glZigZagEntry.GetCurrentTrend();
			Values[0][0] = zz;
			
			Values[2][0] = CurrentBar - glZigZagEntry.GetCurrentLhb();
			Values[3][0] = CurrentBar - glZigZagEntry.GetCurrentLlb();
			
			/*
			Logger(
			"LHB:"+(CurrentBar - glZigZagEntry.GetCurrentLhb()).ToString()+", "+
			"LLB:"+(CurrentBar - glZigZagEntry.GetCurrentLlb()).ToString()
			);
			*/
			
			if (IsFirstTickOfBar){
				Values[0][1] = glPrevTrendEntry;
				Logger(
					"OnBarUpdateSupplyDemandFibExtensionsEntry: "+
					"New bar - "+Time[1].ToString()+": "+glPrevTrendEntry.ToString()
					);
			}
			
			glPrevTrendEntry	= zz;
		}
		
		void OnBarUpdateSupplyDemandFibExtensionsExit() {
			glZigZagExit.ZigZagUpdate(
										CurrentBars[0],
										Highs[0],
										Lows[0],
										pmSdfex_percentamount,
										pmSdfex_revAmount,
										pmSdfex_atrlength,
										pmSdfex_atrreversal,
										10,
										ATRWilders(pmSdfex_atrlength)[0],
										Closes[0][0]
										);
			int 	zz	=	glZigZagExit.GetCurrentTrend();
			Values[1][0] = zz;
			
			Values[4][0] = CurrentBar - glZigZagExit.GetCurrentLhb();
			Values[5][0] = CurrentBar - glZigZagExit.GetCurrentLlb();
			
			if (IsFirstTickOfBar){
				Values[1][1] = glPrevTrendExit;
				Logger(
					"OnBarUpdateSupplyDemandFibExtensionsExit: "+
					"New bar - "+Time[1].ToString()+": "+glPrevTrendExit.ToString()
					);
			}
			
			glPrevTrendExit	= zz;
		}
		
		
		void NewBar(){
			glNewBar	= false;
			DateTime	curTime	= Times[0][1];
			
			if (glNewBarTime != curTime){
				glNewBar		= true;
				glNewBarTime	= curTime;
				Logger(
						"NewBar:"+
						glNewBarTime.ToString()
						);
				
			}
		}

		public void AddInArray(ref double[] arr, double val){
			Array.Resize(ref arr, arr.Length + 1);
			arr[arr.Length - 1] = val;
		}
		
		public void AddInArray(ref string[] arr, string val){
			Array.Resize(ref arr, arr.Length + 1);
			arr[arr.Length - 1] = val;
		}
		
		public void ResetObj(ref IDrawingTool obj){
			if (obj != null){
				RemoveDrawObject(obj.Tag);
				obj = null;
			}
		}
		
		
		void CancelAllEntryOrders(){
			if (glOrders != null){
				foreach (Order order in glOrders){
					if (order != null && !OrderIsInactive(order)) CancelOrder(order);
				}
			}
		}
		
		void CancelAllTragetOrders(){
			if (glOrders != null){
				foreach (Order order in glOrdersTargets){
					if (order != null && !OrderIsInactive(order)) CancelOrder(order);
				}
			}
		}
		
		bool OrderIsInactive(Order order){
			return order.OrderState == OrderState.Cancelled || order.OrderState == OrderState.Filled || order.OrderState == OrderState.Rejected;
		}
		
		
		
		protected override void OnOrderUpdate(Order order, double limitPrice, double stopPrice, int quantity, int filled, double averageFillPrice, OrderState orderState, DateTime time, ErrorCode error, string comment){
			if (pmEnableLog){
				string	msg	=
					String.Format("OnOrderUpdate: State:{0}, OrderState: {1}, Order: {2}",
									State.ToString(),
									order.OrderState.ToString(),
									order.ToString()
									);
				Logger(msg);
			}
			
		}
		
		protected override void OnExecutionUpdate(Execution execution, string executionId, double price, int quantity, MarketPosition marketPosition, string orderId, DateTime time){
			if (pmEnableLog){
				string	msg	=
					String.Format("OnExecutionUpdate: State:{0}, execution.Order: {1}",
									State.ToString(),
									execution.Order.ToString()
									);
				Logger(msg);
			}
			
			OrderState	orState		= execution.Order.OrderState;
			string		orName		= execution.Order.Name;
			double		orFillPrice	= execution.Order.AverageFillPrice;
			
			if (orState == OrderState.Filled){
				int	bar	= pmSdfen_Calculate	== Calculate.OnBarClose ? 2 : 1;
				
				if (orName.Contains(glOrderNameLong)){
					string oco = Guid.NewGuid().ToString("N");
					glOrdersTargets	= new List<Order>();
					if (pmTakeProfit > 0){
						glOrdersTargets.Add(SubmitOrderUnmanaged(BarsInProgress, OrderAction.Sell, OrderType.Limit, quantity, orFillPrice + pmTakeProfit * TickSize, 0, oco, "Profit target"));
					}
					if (pmStopLossType == EnumStopLossType.StopLossTypeHardTicks){
						if (pmStopLoss > 0){
							glOrdersTargets.Add(SubmitOrderUnmanaged(BarsInProgress, OrderAction.Sell, OrderType.StopMarket, quantity, 0, orFillPrice - pmStopLoss * TickSize, oco, "Stop loss"));	
						}
					}
					if (pmStopLossType == EnumStopLossType.StopLossTypeSrZone){
						double	basePrice	= Lows[0][bar];
						double	slPrice		= basePrice - pmStopLossOffset * TickSize;
						glOrdersTargets.Add(SubmitOrderUnmanaged(BarsInProgress, OrderAction.Sell, OrderType.StopMarket, quantity, 0, slPrice, oco, "Stop loss"));	
					}
				}
				if (orName.Contains(glOrderNameShort)){
					string oco = Guid.NewGuid().ToString("N");
					glOrdersTargets	= new List<Order>();
					if (pmTakeProfit > 0){
						glOrdersTargets.Add(SubmitOrderUnmanaged(BarsInProgress, OrderAction.BuyToCover, OrderType.Limit, quantity, orFillPrice - pmTakeProfit * TickSize, 0, oco, "Profit target"));
					}
					if (pmStopLossType == EnumStopLossType.StopLossTypeHardTicks){
						if (pmStopLoss > 0){
							glOrdersTargets.Add(SubmitOrderUnmanaged(BarsInProgress, OrderAction.BuyToCover, OrderType.StopMarket, quantity, 0, orFillPrice + pmStopLoss * TickSize, oco, "Stop loss"));	
						}
					}
					if (pmStopLossType == EnumStopLossType.StopLossTypeSrZone){
						double	basePrice	= Highs[0][bar];
						double	slPrice		= basePrice + pmStopLossOffset * TickSize;
						glOrdersTargets.Add(SubmitOrderUnmanaged(BarsInProgress, OrderAction.BuyToCover, OrderType.StopMarket, quantity, 0, slPrice, oco, "Stop loss"));	
					}
				}
			}
			
		}
		
		protected override void OnPositionUpdate(Position position, double averagePrice, int quantity, MarketPosition marketPosition){
			if (pmEnableLog){
				string	msg	=
					String.Format("OnPositionUpdate: State:{0}, marketPosition: {1}, position:{2}",
									State.ToString(),
									marketPosition.ToString(),
									position.ToString()
									);
				
				Logger(msg);
			}
			
			glFilterMarketPositionSignal.UpdateLock(false,"OnPositionUpdate:");
			///
			
		}    
		
		protected override void OnOrderTrace(DateTime timestamp, string message){
			if (pmEnableLog){
				string	msg	=
					String.Format("OnOrderTrace: State:{0}, timestamp: {1}, message:{2}",
									State,
									timestamp,
									message
									);
				
				if (State == State.Historical || State == State.Realtime)
					Logger(msg);
			}
			///
			
		}	
		
		
		
		#endregion
		
		#region Classes
		#region Logger
		
		public void Logger(string msg, LogLevel logLevel = LogLevel.Information){
			if (!pmEnableLog) return;
			string	text	= string.Format(
				"{0} Logger: {1} {2} {3}",
				this,
				Instrument.FullName,
				Times[0][0].ToString(),
				msg
				);
			
			if (State != State.Historical) Log(text,logLevel);
			Print(text);
		}
		
		#endregion
		
		#region Enums
		public enum EnumStopLossType{
			StopLossTypeHardTicks,
			StopLossTypeSrZone,
		}
		
		public enum EnumDirectionType{
			Long,
			Short,
			Both,
		}
		
		
		
		public enum SignalType{
			Buy,
			Sell,
			No,
			Both
		}
		const SignalType BUY = SignalType.Buy;
		const SignalType SELL = SignalType.Sell;
		const SignalType NO = SignalType.No;
		const SignalType BOTH = SignalType.Both;
		#endregion
		
		#region Signals
			public class SignalHandler{
				private List<Signal> 		signals;
				private AlexKamunyaStrategy1v3 	s;
				private string 				shName;
				
				public SignalHandler(AlexKamunyaStrategy1v3 s, string name){
					signals = new List<Signal>();
					this.s 	= s;
					shName	= name;
				}
				
				public void AddSignal(Signal signal){
					signals.Add(signal);
				}
				
				public void OnTick(){
					foreach (Signal signal in signals){
						signal.CalculateOpenSignal();
						signal.CalculateCloseSignal();
					}
				}
				
				public void LogOpenSignal(){
					if (!s.pmEnableLog) return;
					
					foreach (Signal signal in signals){
						signal.LogOpenSignal();
					}
					s.Logger(shName+": Open signal = "+GetOpenSignal().ToString());
				}
				
				public void LogCloseSignal(){
					if (!s.pmEnableLog) return;
					
					foreach (Signal signal in signals){
						signal.LogCloseSignal();
					}
					s.Logger(shName+": Close signal = "+GetCloseSignal().ToString());
				}

				public SignalType GetOpenSignal(){
					SignalType openSignal = NO;
					int signalBuy = 0;
					int signalSell = 0;
					foreach (Signal signal in signals){
						if (signal.GetOpenSignal() == BUY)
							signalBuy++;
						if (signal.GetOpenSignal() == SELL)
							signalSell++;
						if (signal.GetOpenSignal() == BOTH){
							signalSell++;
							signalBuy++;
						}
					}
					if (signalBuy == signals.Count)
						openSignal = BUY;
					if (signalSell == signals.Count)
						openSignal = SELL;
					if (signalBuy == signals.Count && signalSell == signals.Count)
						openSignal = BOTH;
					return openSignal;
				}
				
				public SignalType GetCloseSignal(){
					SignalType closeSignal = NO;
					int signalBuy = 0;
					int signalSell = 0;
					foreach (Signal signal in signals){
						if (signal.GetCloseSignal() == BUY)
							signalBuy++;
						if (signal.GetCloseSignal() == SELL)
							signalSell++;
						if (signal.GetCloseSignal() == BOTH){
							signalSell++;
							signalBuy++;
						}
					}
					if (signalBuy > 0)
						closeSignal = BUY;
					if (signalSell > 0)
						closeSignal = SELL;
					if (signalBuy > 0 && signalSell > 0)
						closeSignal = BOTH;
					return closeSignal;
				}
				
				public List<Signal> getSignals(){
					return signals;
				}
			}
		
			public abstract class Signal{
				protected AlexKamunyaStrategy1v3  s;
				
				protected double[] openVals 		= new double[1];
				protected string[] openStringVals 	= new string[1];
				
				protected double[] closeVals 		= new double[1];
				protected string[] closeStringVals	= new string[1];
				
				protected SignalType openSignal;
				protected SignalType closeSignal;
				
				public Signal(AlexKamunyaStrategy1v3  s){
					this.s = s;
				}
				
				public SignalType GetOpenSignal(){
					return openSignal;
				}
				
				public SignalType GetCloseSignal(){
					return closeSignal;
				}
				
				public abstract void CalculateOpenSignal();
				
				public abstract void CalculateCloseSignal();
				
				public virtual void LogOpenSignal(){
					if (!s.pmEnableLog) return;
					
					SignalType signal = GetOpenSignal();
					string parameters = "";
					foreach (Object val in openStringVals){
						parameters += (val+ ", ");
					}
					foreach (Object val in openVals){
						parameters += (val.ToString() + ", ");
					}
					parameters = parameters.Remove(parameters.Length - 2);
					s.Logger(this.GetType().Name+": Open signal "+signal+". Parameters: "+parameters);
				}
				
				public virtual void LogCloseSignal(){
					if (!s.pmEnableLog) return;
					
					SignalType signal = GetCloseSignal();
					string parameters = "";
					foreach (Object val in closeStringVals){
						parameters += (val + ", ");
					}
					foreach (Object val in closeVals){
						parameters += (val.ToString() + ", ");
					}
					parameters = parameters.Remove(parameters.Length - 2);
					s.Logger(this.GetType().Name+": Close signal "+signal+". Parameters: "+parameters);
				}
			}
			
			public class FilterMarketPositionSignal : Signal{
				public bool sPositionLock{get;set;}
				
				public FilterMarketPositionSignal(AlexKamunyaStrategy1v3 s) : base(s){
				}
				
				public void UpdateLock(bool state, string reason){
					if (sPositionLock != state){
						sPositionLock	= state;
						
						if (s.pmEnableLog){
							s.Logger(
									"FilterMarketPositionSignal:UpdateLock:"+
									sPositionLock.ToString()+", "+
									reason
									);
									
						}
						
					}
				}
				
				public override void CalculateOpenSignal(){
					openSignal 		= NO;
						
					int coef = (s.Position.MarketPosition == MarketPosition.Long) ? 1 : -1;
					int pos	 = coef * s.Position.Quantity;
					
					if (s.pmEnableZoneTarget){
						if (pos <= 0)
							openSignal = BUY;
						if (pos >= 0)
							openSignal = openSignal == NO ? SELL : BOTH;
					}
					else{
						if (pos == 0)
							openSignal = BOTH;
					}
					
					if (s.pmEnableLog){
						openVals 		= new double[0];
						openStringVals 	= new string[0];
						
						s.AddInArray(ref openStringVals, pos.ToString());
						s.AddInArray(ref openStringVals, sPositionLock.ToString());
						s.AddInArray(ref openStringVals, s.pmEnableZoneTarget.ToString());
					}
						
				}
				
				public override void CalculateCloseSignal(){
					closeSignal = NO;
				}
			}
			
			public class FilterTradeDirectionSignal : Signal{
				public FilterTradeDirectionSignal(AlexKamunyaStrategy1v3 s) : base(s){
				}
				
				public override void CalculateOpenSignal(){
					openSignal 		= NO;
						
					bool	isBuy	= s.pmDirectionType != EnumDirectionType.Short;
					bool	isSell	= s.pmDirectionType != EnumDirectionType.Long;
					
					if (isBuy)
						openSignal = BUY;
					if (isSell)
						openSignal = openSignal == NO ? SELL : BOTH;
					
					if (s.pmEnableLog){
						openVals 		= new double[0];
						openStringVals 	= new string[0];
						
						s.AddInArray(ref openStringVals, isBuy.ToString());
						s.AddInArray(ref openStringVals, isSell.ToString());
						s.AddInArray(ref openStringVals, s.pmDirectionType.ToString());
					}
						
				}
				
				public override void CalculateCloseSignal(){
					closeSignal = NO;
				}
			}
			
			public class CalculateEntryZzTrendChangedSignal : Signal{
				public	int	sLastLowIndex;
				public	int	sLastHighIndex;
				
				public CalculateEntryZzTrendChangedSignal(AlexKamunyaStrategy1v3 s) : base(s){
				}
				
				public override void CalculateOpenSignal(){
					openSignal 		= NO;
					
					sLastLowIndex	= -1;
					sLastHighIndex	= -1;
					
					int	countP	= s.glZigZagEntry.Points.Count;
					int	countI	= s.glZigZagEntry.Indices.Count;
					
					bool	isReady	= countP == countI && countI > 1;
					
					int		buyCount	= 0;
					int		sellCount	= 0;
					int		lastIndex	= -1;
					
					string	msgLog			= "";
					
					for (int i = countP - 1; i >= 1; i--){
						int		inedc1	= s.glZigZagEntry.Indices[i];
						int		inedc2	= s.glZigZagEntry.Indices[i-1];
						double	price1	= s.glZigZagEntry.Points[i];
						double	price2	= s.glZigZagEntry.Points[i-1];
						
						bool	isBuy	= price1 > price2;
						
						msgLog	+=
								" | "+
								i.ToString()+", "+
								isBuy.ToString()+", "+
								s.CurrentBar.ToString()+", "+
								inedc1.ToString()+", "+
								inedc2.ToString()+" : "+
								price1.ToString()+", "+
								price2.ToString()
								;
								
						
						if (isBuy){
							if (sellCount > 0){
								break;	
							}
							buyCount++;
						}
						if (!isBuy){
							if (buyCount > 0){
								break;	
							}
							sellCount++;
						}
						
						lastIndex	= i-1;
					}
					
					bool	isFound	= lastIndex != -1;
					
					if (isFound){
						bool	isBuy	= buyCount > 0;
						bool	isSell	= sellCount > 0;
						
						if (isBuy){
							sLastLowIndex	= s.glZigZagEntry.Indices[lastIndex];
							openSignal	= BUY;
						}
						if (isSell){
							sLastHighIndex	= s.glZigZagEntry.Indices[lastIndex];
							openSignal	= openSignal == NO ? SELL : BOTH;
						}
						
					}
					
					if (s.pmEnableLog){
						openVals 		= new double[0];
						openStringVals 	= new string[0];
					
						s.AddInArray(ref openStringVals, sLastLowIndex.ToString());
						s.AddInArray(ref openStringVals, sLastHighIndex.ToString());
						
						s.AddInArray(ref openStringVals, " | ");
						s.AddInArray(ref openStringVals, isFound.ToString());
						s.AddInArray(ref openStringVals, isReady.ToString());
						
						s.AddInArray(ref openStringVals, " | ");
						s.AddInArray(ref openStringVals, buyCount.ToString());
						s.AddInArray(ref openStringVals, sellCount.ToString());
						s.AddInArray(ref openStringVals, lastIndex.ToString());
						
						s.AddInArray(ref openStringVals, " | ");
						s.AddInArray(ref openStringVals, msgLog);
					}
				}
				
				public override void CalculateCloseSignal(){
					closeSignal = NO;
				}
			}
			
			public class CalculateExitZzTrendChangedSignal : Signal{
				public	int	sLastLowIndex;
				public	int	sLastHighIndex;
				
				public CalculateExitZzTrendChangedSignal(AlexKamunyaStrategy1v3 s) : base(s){
				}
				
				public override void CalculateOpenSignal(){
					openSignal 		= NO;
					
					sLastLowIndex	= -1;
					sLastHighIndex	= -1;
					
					int	countP	= s.glZigZagExit.Points.Count;
					int	countI	= s.glZigZagExit.Indices.Count;
					
					bool	isReady	= countP == countI && countI > 1;
					
					int		buyCount	= 0;
					int		sellCount	= 0;
					int		lastIndex	= -1;
					
					string	msgLog			= "";
					
					for (int i = countP - 1; i >= 1; i--){
						int		inedc1	= s.glZigZagExit.Indices[i];
						int		inedc2	= s.glZigZagExit.Indices[i-1];
						double	price1	= s.glZigZagExit.Points[i];
						double	price2	= s.glZigZagExit.Points[i-1];
						
						bool	isBuy	= price1 > price2;
						
						msgLog	+=
								" | "+
								i.ToString()+", "+
								isBuy.ToString()+", "+
								s.CurrentBar.ToString()+", "+
								inedc1.ToString()+", "+
								inedc2.ToString()+" : "+
								price1.ToString()+", "+
								price2.ToString()
								;
								
						
						if (isBuy){
							if (sellCount > 0){
								break;	
							}
							buyCount++;
						}
						if (!isBuy){
							if (buyCount > 0){
								break;	
							}
							sellCount++;
						}
						
						lastIndex	= i-1;
					}
					
					bool	isFound	= lastIndex != -1;
					
					if (isFound){
						bool	isBuy	= buyCount > 0;
						bool	isSell	= sellCount > 0;
						
						if (isBuy){
							sLastLowIndex	= s.glZigZagExit.Indices[lastIndex];
							openSignal	= BUY;
						}
						if (isSell){
							sLastHighIndex	= s.glZigZagExit.Indices[lastIndex];
							openSignal	= openSignal == NO ? SELL : BOTH;
						}
						
					}
					
					if (s.pmEnableLog){
						openVals 		= new double[0];
						openStringVals 	= new string[0];
					
						s.AddInArray(ref openStringVals, sLastLowIndex.ToString());
						s.AddInArray(ref openStringVals, sLastHighIndex.ToString());
						
						s.AddInArray(ref openStringVals, " | ");
						s.AddInArray(ref openStringVals, isFound.ToString());
						s.AddInArray(ref openStringVals, isReady.ToString());
						
						s.AddInArray(ref openStringVals, " | ");
						s.AddInArray(ref openStringVals, buyCount.ToString());
						s.AddInArray(ref openStringVals, sellCount.ToString());
						s.AddInArray(ref openStringVals, lastIndex.ToString());
						
						s.AddInArray(ref openStringVals, " | ");
						s.AddInArray(ref openStringVals, msgLog);
					}
				}
				
				public override void CalculateCloseSignal(){
					closeSignal = NO;
				}
			}
			
			public class EntrySupDemFibChangesSignal : Signal{
				int	sLastBlockedBarEntry;
				int	sLastBlockedBarExit;
				
				public EntrySupDemFibChangesSignal(AlexKamunyaStrategy1v3 s) : base(s){
					sLastBlockedBarEntry = 0;
					sLastBlockedBarExit = 0;
				}
				
				public override void CalculateOpenSignal(){
					if (s.pmSdfen_Calculate == Calculate.OnBarClose){
						CalculateOpenSignalOnBarClose();
					}
					else{
						CalculateOpenSignalOnEachTick();
					}
				}
				
				public override void CalculateCloseSignal(){
					if (s.pmSdfex_Calculate == Calculate.OnBarClose){
						CalculateCloseSignalOnBarClose();
					}
					else{
						CalculateCloseSignalOnEachTick();
					}
				}
				
				void CalculateOpenSignalOnEachTick(){
					openSignal 			= NO;
					
					if (s.pmEnableLog){
						openVals 		= new double[0];
						openStringVals 	= new string[0];
					}
					
					int		bar			= 0;
					
					int		lastHigh	= s.glCalculateEntryZzTrendChangedSignal.sLastHighIndex;
					int		lastLow		= s.glCalculateEntryZzTrendChangedSignal.sLastLowIndex;
					
					int		lastH 		= lastHigh != -1 	? s.CurrentBar - lastHigh 	: -1;
					int		lastL 		= lastLow != -1 	? s.CurrentBar - lastLow 	: -1;
					
					bool	isBuy		= lastL == 1;
					bool	isSell		= lastH == 1;
					
					string	msg	= "";
					
					string	dir1	= isBuy ? "Buy" : isSell ? "Sell" : "No";
							
			
					msg	+= 
							"S Sig: "+dir1 +
							": CB:"+s.CurrentBar.ToString()+
							", LHB:"+lastH.ToString()+
							", LLB:"+lastL.ToString()+
							", LH:"+lastHigh.ToString()+
							", LL:"+lastLow.ToString()
							;
					
					Draw.TextFixed(
									s, 
									"Text", 
									msg, 
									TextPosition.BottomRight, 
									s.ChartControl.Properties.ChartText,
					  				s.ChartControl.Properties.LabelFont, 
									s.ChartControl.Properties.ChartText, 
									Brushes.Transparent, 
									0
									);
					
					int		curBar		= s.CurrentBar;
					
					if (isBuy && sLastBlockedBarEntry != curBar){
						openSignal = BUY;
						UpdateLastBlockedBarEntry(curBar,"isBuy");
					}
					if (isSell && sLastBlockedBarEntry != curBar){
						openSignal = SELL;
						UpdateLastBlockedBarEntry(curBar,"isSell");
					}
					
					if (s.pmEnableLog){
					
						s.AddInArray(ref openStringVals, isBuy.ToString());
						s.AddInArray(ref openStringVals, isSell.ToString());
						s.AddInArray(ref openStringVals, sLastBlockedBarEntry.ToString());
						s.AddInArray(ref openStringVals, s.CurrentBar.ToString());
						s.AddInArray(ref openStringVals, lastH.ToString());
						s.AddInArray(ref openStringVals, lastL.ToString());
						s.AddInArray(ref openStringVals, lastHigh.ToString());
						s.AddInArray(ref openStringVals, lastLow.ToString());
						s.AddInArray(ref openStringVals, s.pmSdfen_Calculate.ToString());
					}
				}

				void CalculateOpenSignalOnBarClose(){
					openSignal 			= NO;
					
					int		bar			= 1;
					
					int		lastHigh	= s.glCalculateEntryZzTrendChangedSignal.sLastHighIndex;
					int		lastLow		= s.glCalculateEntryZzTrendChangedSignal.sLastLowIndex;
					
					int		lastH 		= lastHigh != -1 	? s.CurrentBar - lastHigh 	: -1;
					int		lastL 		= lastLow != -1 	? s.CurrentBar - lastLow 	: -1;
					
					bool	isBuy		= lastL == 2;
					bool	isSell		= lastH == 2;
					
					string	msg	= "";
					
					string	dir1	= isBuy ? "Buy" : isSell ? "Sell" : "No";
							
			
					msg	+= 
							"S Sig: "+dir1 +
							": CB:"+s.CurrentBar.ToString()+
							", LHB:"+lastH.ToString()+
							", LLB:"+lastL.ToString()+
							", LH:"+lastHigh.ToString()+
							", LL:"+lastLow.ToString()
							;
					
					Draw.TextFixed(
									s, 
									"Text", 
									msg, 
									TextPosition.BottomRight, 
									s.ChartControl.Properties.ChartText,
					  				s.ChartControl.Properties.LabelFont, 
									s.ChartControl.Properties.ChartText, 
									Brushes.Transparent, 
									0
									);
					
					
					if (isBuy)
						openSignal = BUY;
					if (isSell)
						openSignal = openSignal == NO ? SELL : BOTH;
					
					if (s.pmEnableLog){
						openVals 		= new double[0];
						openStringVals 	= new string[0];
					
						s.AddInArray(ref openStringVals, isBuy.ToString());
						s.AddInArray(ref openStringVals, isSell.ToString());
						s.AddInArray(ref openStringVals, s.CurrentBar.ToString());
						s.AddInArray(ref openStringVals, lastH.ToString());
						s.AddInArray(ref openStringVals, lastL.ToString());
						s.AddInArray(ref openStringVals, lastHigh.ToString());
						s.AddInArray(ref openStringVals, lastLow.ToString());
						s.AddInArray(ref openStringVals, s.pmSdfen_Calculate.ToString());
					}
				}
				
				void CalculateCloseSignalOnEachTick(){
					closeSignal 			= NO;
					
					if (s.pmEnableLog){
						closeVals 		= new double[0];
						closeStringVals	= new string[0];
					}
					
					
					int		bar			= 0;
					
					int		lastHigh	= s.glCalculateExitZzTrendChangedSignal.sLastHighIndex;
					int		lastLow		= s.glCalculateExitZzTrendChangedSignal.sLastLowIndex;
					
					int		lastH 		= lastHigh != -1 	? s.CurrentBar - lastHigh 	: -1;
					int		lastL 		= lastLow != -1 	? s.CurrentBar - lastLow 	: -1;
					
					bool	isBuy		= lastL == 1;
					bool	isSell		= lastH == 1;
					
					int		curBar		= s.CurrentBar;
					
					if (isBuy && sLastBlockedBarExit != curBar){
						closeSignal = BUY;
						UpdateLastBlockedBarExit(curBar,"isBuy");
					}
					if (isSell && sLastBlockedBarExit != curBar){
						closeSignal = SELL;
						UpdateLastBlockedBarExit(curBar,"isSell");
					}
					
					if (s.pmEnableLog){
					
						s.AddInArray(ref closeStringVals, isBuy.ToString());
						s.AddInArray(ref closeStringVals, isSell.ToString());
						s.AddInArray(ref closeStringVals, sLastBlockedBarExit.ToString());
						s.AddInArray(ref closeStringVals, s.CurrentBar.ToString());
						s.AddInArray(ref closeStringVals, lastH.ToString());
						s.AddInArray(ref closeStringVals, lastL.ToString());
						s.AddInArray(ref closeStringVals, lastHigh.ToString());
						s.AddInArray(ref closeStringVals, lastLow.ToString());
						s.AddInArray(ref closeStringVals, s.pmSdfex_Calculate.ToString());
					}
				}
				
				void CalculateCloseSignalOnBarClose(){
					closeSignal = NO;
					
					int		bar			= 1;
					
					int		lastHigh	= s.glCalculateExitZzTrendChangedSignal.sLastHighIndex;
					int		lastLow		= s.glCalculateExitZzTrendChangedSignal.sLastLowIndex;
					
					int		lastH 		= lastHigh != -1 	? s.CurrentBar - lastHigh 	: -1;
					int		lastL 		= lastLow != -1 	? s.CurrentBar - lastLow 	: -1;
					
					bool	isBuy		= lastL == 2;
					bool	isSell		= lastH == 2;
					
					if (isBuy)
						closeSignal = BUY;
					if (isSell)
						closeSignal = closeSignal == NO ? SELL : BOTH;
					
					if (s.pmEnableLog){
						closeVals 		= new double[0];
						closeStringVals	= new string[0];
					
						s.AddInArray(ref closeStringVals, isBuy.ToString());
						s.AddInArray(ref closeStringVals, isSell.ToString());
						s.AddInArray(ref closeStringVals, s.CurrentBar.ToString());
						s.AddInArray(ref closeStringVals, lastH.ToString());
						s.AddInArray(ref closeStringVals, lastL.ToString());
						s.AddInArray(ref closeStringVals, lastHigh.ToString());
						s.AddInArray(ref closeStringVals, lastLow.ToString());
						s.AddInArray(ref closeStringVals, s.pmSdfex_Calculate.ToString());
					}
				}
				
				
				void UpdateLastBlockedBarEntry(int bar, string reason){
					if (sLastBlockedBarEntry != bar){
						int old		= sLastBlockedBarEntry;
						sLastBlockedBarEntry	= bar;
						
						if (s.pmEnableLog){
							s.Logger(
										"EntrySupDemFibChangesSignal:UpdateLastBlockedBarEntry: "+
										sLastBlockedBarEntry.ToString()+", "+
										old.ToString()+", "+
										reason
										);
						}
						
					}
				}
				
				void UpdateLastBlockedBarExit(int bar, string reason){
					if (sLastBlockedBarExit != bar){
						int old		= sLastBlockedBarExit;
						sLastBlockedBarExit	= bar;
						
						if (s.pmEnableLog){
							s.Logger(
										"EntrySupDemFibChangesSignal:UpdateLastBlockedBarExit: "+
										sLastBlockedBarExit.ToString()+", "+
										old.ToString()+", "+
										reason
										);
						}
						
					}
				}
			}
		
			public class EntrySupDemFibChangesSignalOld : Signal{
				SignalType	sLastSignalEntry;
				SignalType	sLastSignalExit;
				
				public EntrySupDemFibChangesSignalOld(AlexKamunyaStrategy1v3 s) : base(s){
					sLastSignalEntry = NO;
					sLastSignalExit = NO;
				}
				
				public override void CalculateOpenSignal(){
					if (s.pmSdfen_Calculate == Calculate.OnBarClose){
						CalculateOpenSignalOnBarClose();
					}
					else{
						CalculateOpenSignalOnEachTick();
					}
				}
				
				public override void CalculateCloseSignal(){
					if (s.pmSdfex_Calculate == Calculate.OnBarClose){
						CalculateCloseSignalOnBarClose();
					}
					else{
						CalculateCloseSignalOnEachTick();
					}
				}
				
				void CalculateOpenSignalOnEachTick(){
					openSignal 			= NO;
					
					if (s.pmEnableLog){
						openVals 		= new double[0];
						openStringVals 	= new string[0];
					}
					
					if (sLastSignalEntry == NO){
						int		bar			= 1;
						
						double	val0		= s.Values[0][bar];
						bool	isVal0		= s.Values[0].IsValidDataPoint(bar);
						
						bool	isBuy		= val0 > 0;
						bool	isSell		= val0 < 0;
						bool	isNotNull	= isVal0;
						
						if (isNotNull){
							if (isBuy)
								UpdateLastSignalEntry(BUY,"INIT:isBuy");
							if (isSell)
								UpdateLastSignalEntry(SELL,"INIT:isBuy");
						}
						
						if (s.pmEnableLog){
							
							s.AddInArray(ref openStringVals, "I START");
							s.AddInArray(ref openStringVals, isNotNull.ToString());
							s.AddInArray(ref openStringVals, isBuy.ToString());
							s.AddInArray(ref openStringVals, isSell.ToString());
							s.AddInArray(ref openStringVals, sLastSignalEntry.ToString());
							s.AddInArray(ref openStringVals, val0.ToString());
							s.AddInArray(ref openStringVals, isVal0.ToString());
							s.AddInArray(ref openStringVals, "I END");
						}
					}
					
					if (sLastSignalEntry != NO){
					
						int		bar			= 0;
						
						double	val0		= s.Values[0][bar];
						bool	isVal0		= s.Values[0].IsValidDataPoint(bar);
						
						double	val1		= s.Values[0][bar + 1];
						bool	isVal1		= s.Values[0].IsValidDataPoint(bar + 1);
						
						bool	isBuy		= val0 > 0;// && val1 < 0;
						bool	isSell		= val0 < 0;// && val1 > 0;
						bool	isNotNull	= isVal0;// && isVal1;
						
						if (isNotNull){
							if (isBuy && sLastSignalEntry != BUY){
								openSignal = BUY;
								UpdateLastSignalEntry(openSignal,"isBuy");
							}
							if (isSell && sLastSignalEntry != SELL){
								openSignal = SELL;
								UpdateLastSignalEntry(openSignal,"isSell");
							}
						}
						
						if (s.pmEnableLog){
						
							s.AddInArray(ref openStringVals, isNotNull.ToString());
							s.AddInArray(ref openStringVals, isBuy.ToString());
							s.AddInArray(ref openStringVals, isSell.ToString());
							s.AddInArray(ref openStringVals, sLastSignalEntry.ToString());
							s.AddInArray(ref openStringVals, val0.ToString());
							s.AddInArray(ref openStringVals, val1.ToString());
							s.AddInArray(ref openStringVals, isVal0.ToString());
							s.AddInArray(ref openStringVals, isVal1.ToString());
							s.AddInArray(ref openStringVals, s.pmSdfen_Calculate.ToString());
						}
					}
				}

				void CalculateOpenSignalOnBarClose(){
					openSignal 			= NO;
					
					int		bar			= 1;
					
					double	val0		= s.Values[0][bar];
					bool	isVal0		= s.Values[0].IsValidDataPoint(bar);
					
					double	val1		= s.Values[0][bar + 1];
					bool	isVal1		= s.Values[0].IsValidDataPoint(bar + 1);
					
					bool	isBuy		= val0 > 0 && val1 < 0;
					bool	isSell		= val0 < 0 && val1 > 0;
					bool	isNotNull	= isVal0 && isVal1;
					
					if (isNotNull){
						if (isBuy)
							openSignal = BUY;
						if (isSell)
							openSignal = openSignal == NO ? SELL : BOTH;
					}
					
					if (s.pmEnableLog){
						openVals 		= new double[0];
						openStringVals 	= new string[0];
					
						s.AddInArray(ref openStringVals, isNotNull.ToString());
						s.AddInArray(ref openStringVals, isBuy.ToString());
						s.AddInArray(ref openStringVals, isSell.ToString());
						s.AddInArray(ref openStringVals, val0.ToString());
						s.AddInArray(ref openStringVals, val1.ToString());
						s.AddInArray(ref openStringVals, isVal0.ToString());
						s.AddInArray(ref openStringVals, isVal1.ToString());
						s.AddInArray(ref openStringVals, s.pmSdfen_Calculate.ToString());
					}
					
					
					
					
				}
				
				void CalculateCloseSignalOnEachTick(){
					closeSignal 			= NO;
					
					if (s.pmEnableLog){
						closeVals 		= new double[0];
						closeStringVals	= new string[0];
					}
					
					if (sLastSignalExit == NO){
						int		bar			= 1;
						
						double	val0		= s.Values[1][bar];
						bool	isVal0		= s.Values[1].IsValidDataPoint(bar);
						
						bool	isBuy		= val0 > 0;
						bool	isSell		= val0 < 0;
						bool	isNotNull	= isVal0;
						
						if (isNotNull){
							if (isBuy)
								UpdateLastSignalExit(BUY,"INIT:isBuy");
							if (isSell)
								UpdateLastSignalExit(SELL,"INIT:isBuy");
						}
						
						if (s.pmEnableLog){
							
							s.AddInArray(ref closeStringVals, "I START");
							s.AddInArray(ref closeStringVals, isNotNull.ToString());
							s.AddInArray(ref closeStringVals, isBuy.ToString());
							s.AddInArray(ref closeStringVals, isSell.ToString());
							s.AddInArray(ref closeStringVals, sLastSignalExit.ToString());
							s.AddInArray(ref closeStringVals, val0.ToString());
							s.AddInArray(ref closeStringVals, isVal0.ToString());
							s.AddInArray(ref closeStringVals, "I END");
						}
					}
					
					if (sLastSignalExit != NO){
					
						int		bar			= 0;
						
						double	val0		= s.Values[1][bar];
						bool	isVal0		= s.Values[1].IsValidDataPoint(bar);
						
						double	val1		= s.Values[1][bar + 1];
						bool	isVal1		= s.Values[1].IsValidDataPoint(bar + 1);
						
						bool	isBuy		= val0 > 0;// && val1 < 0;
						bool	isSell		= val0 < 0;// && val1 > 0;
						bool	isNotNull	= isVal0;// && isVal1;
						
						if (isNotNull){
							if (isBuy && sLastSignalExit != BUY){
								closeSignal = BUY;
								UpdateLastSignalExit(closeSignal,"isBuy");
							}
							if (isSell && sLastSignalExit != SELL){
								closeSignal = SELL;
								UpdateLastSignalExit(closeSignal,"isSell");
							}
						}
						
						if (s.pmEnableLog){
						
							s.AddInArray(ref closeStringVals, isNotNull.ToString());
							s.AddInArray(ref closeStringVals, isBuy.ToString());
							s.AddInArray(ref closeStringVals, isSell.ToString());
							s.AddInArray(ref closeStringVals, sLastSignalExit.ToString());
							s.AddInArray(ref closeStringVals, val0.ToString());
							s.AddInArray(ref closeStringVals, val1.ToString());
							s.AddInArray(ref closeStringVals, isVal0.ToString());
							s.AddInArray(ref closeStringVals, isVal1.ToString());
							s.AddInArray(ref closeStringVals, s.pmSdfex_Calculate.ToString());
						}
					}
				}
				
				void CalculateCloseSignalOnBarClose(){
					closeSignal = NO;
					
					int		bar			= 1;
					
					double	val0		= s.Values[1][bar];
					bool	isVal0		= s.Values[1].IsValidDataPoint(bar);
					
					double	val1		= s.Values[1][bar + 1];
					bool	isVal1		= s.Values[1].IsValidDataPoint(bar + 1);
					
					bool	isBuy		= val0 > 0 && val1 < 0;
					bool	isSell		= val0 < 0 && val1 > 0;
					bool	isNotNull	= isVal0 && isVal1;
					
					if (isNotNull){
						if (isBuy)
							closeSignal = BUY;
						if (isSell)
							closeSignal = closeSignal == NO ? SELL : BOTH;
					}
					
					if (s.pmEnableLog){
						closeVals 		= new double[0];
						closeStringVals	= new string[0];
					
						s.AddInArray(ref closeStringVals, isNotNull.ToString());
						s.AddInArray(ref closeStringVals, isBuy.ToString());
						s.AddInArray(ref closeStringVals, isSell.ToString());
						s.AddInArray(ref closeStringVals, val0.ToString());
						s.AddInArray(ref closeStringVals, val1.ToString());
						s.AddInArray(ref closeStringVals, isVal0.ToString());
						s.AddInArray(ref closeStringVals, isVal1.ToString());
						s.AddInArray(ref closeStringVals, s.pmSdfex_Calculate.ToString());
					}
				}
				
				
				void UpdateLastSignalEntry(SignalType signal, string reason){
					if (sLastSignalEntry != signal){
						SignalType old		= sLastSignalEntry;
						sLastSignalEntry	= signal;
						
						if (s.pmEnableLog){
							s.Logger(
										"EntrySupDemFibChangesSignal:UpdateLastSignalEntry: "+
										sLastSignalEntry.ToString()+", "+
										old.ToString()+", "+
										reason
										);
						}
						
					}
				}
				
				void UpdateLastSignalExit(SignalType signal, string reason){
					if (sLastSignalExit != signal){
						SignalType old		= sLastSignalExit;
						sLastSignalExit	= signal;
						
						if (s.pmEnableLog){
							s.Logger(
										"EntrySupDemFibChangesSignal:UpdateLastSignalExit: "+
										sLastSignalExit.ToString()+", "+
										old.ToString()+", "+
										reason
										);
						}
						
					}
				}
			}
		
		
			
			public class FilterGbChandelierStopIndicatorSignal : Signal{
				public FilterGbChandelierStopIndicatorSignal(AlexKamunyaStrategy1v3 s) : base(s){
				}
				
				public override void CalculateOpenSignal(){
					openSignal 		= NO;
					
					int		bar		= s.pmSdfen_Calculate == Calculate.OnBarClose ? 1 : 0;
					
					bool	up		= s.glGbChandelierStop.Values[1].IsValidDataPoint(bar);
					double	up0		= s.glGbChandelierStop.Values[1][bar];
					bool	upTrans	= s.glGbChandelierStop.PlotBrushes[1][bar] == Brushes.Transparent;
					
					bool	dn		= s.glGbChandelierStop.Values[0].IsValidDataPoint(bar);
					double	dn0		= s.glGbChandelierStop.Values[0][bar];
					bool	dnTrans	= s.glGbChandelierStop.PlotBrushes[0][bar] == Brushes.Transparent;
					
					bool	isBuy	= !upTrans && up;
					bool	isSell	= !dnTrans && dn;
					
					if (isBuy)
						openSignal = BUY;
					if (isSell)
						openSignal = (openSignal == NO) ? SELL : BOTH;
					
					if (s.pmEnableLog){
						openVals 		= new double[0];
						openStringVals 	= new string[0];
					
						s.AddInArray(ref openStringVals, isBuy.ToString());
						s.AddInArray(ref openStringVals, isSell.ToString());
						
						s.AddInArray(ref openStringVals, " | ");
						s.AddInArray(ref openStringVals, up.ToString());
						s.AddInArray(ref openStringVals, upTrans.ToString());
						s.AddInArray(ref openStringVals, up0.ToString());
						
						s.AddInArray(ref openStringVals, " | ");
						s.AddInArray(ref openStringVals, dn.ToString());
						s.AddInArray(ref openStringVals, dnTrans.ToString());
						s.AddInArray(ref openStringVals, dn0.ToString());
						
						s.AddInArray(ref openStringVals, " | ");
						s.AddInArray(ref openStringVals, bar.ToString());
						s.AddInArray(ref openStringVals, s.pmSdfen_Calculate.ToString());
					}
				}
				
				public override void CalculateCloseSignal(){
					closeSignal = NO;
				}
			}
		
			public class FilterGbChandelierStopIndicatorTickOffsetSignal : Signal{
				public FilterGbChandelierStopIndicatorTickOffsetSignal(AlexKamunyaStrategy1v3 s) : base(s){
				}
				
				public override void CalculateOpenSignal(){
					openSignal 		= NO;
					
					int		bar		= s.pmSdfen_Calculate == Calculate.OnBarClose ? 1 : 0;
					
					bool	up		= s.glGbChandelierStop.Values[1].IsValidDataPoint(bar);
					double	up0		= s.glGbChandelierStop.Values[1][bar];
					
					bool	dn		= s.glGbChandelierStop.Values[0].IsValidDataPoint(bar);
					double	dn0		= s.glGbChandelierStop.Values[0][bar];
					
					double	close	= s.Closes[0][bar];
					double	upDist	= (close - up0) / s.TickSize;
					double	dnDist	= (dn0 - close) / s.TickSize;
					
					bool	isBuy	= up && upDist >= s.pmTrendFilterTicksOffset;
					bool	isSell	= dn && dnDist >= s.pmTrendFilterTicksOffset;
					
					if (isBuy)
						openSignal = BUY;
					if (isSell)
						openSignal = (openSignal == NO) ? SELL : BOTH;
					
					if (s.pmEnableLog){
						openVals 		= new double[0];
						openStringVals 	= new string[0];
					
						s.AddInArray(ref openStringVals, isBuy.ToString());
						s.AddInArray(ref openStringVals, isSell.ToString());
						s.AddInArray(ref openStringVals, s.pmTrendFilterTicksOffset.ToString());
						s.AddInArray(ref openStringVals, close.ToString());
						
						s.AddInArray(ref openStringVals, " | ");
						s.AddInArray(ref openStringVals, up.ToString());
						s.AddInArray(ref openStringVals, up0.ToString());
						s.AddInArray(ref openStringVals, dnDist.ToString());
						
						s.AddInArray(ref openStringVals, " | ");
						s.AddInArray(ref openStringVals, dn.ToString());
						s.AddInArray(ref openStringVals, dn0.ToString());
						s.AddInArray(ref openStringVals, dnDist.ToString());
						
						s.AddInArray(ref openStringVals, " | ");
						s.AddInArray(ref openStringVals, bar.ToString());
						s.AddInArray(ref openStringVals, s.pmSdfen_Calculate.ToString());
					}
				}
				
				public override void CalculateCloseSignal(){
					closeSignal = NO;
				}
			}
		

		#endregion
		
		#region Zigzag
		private class Zigzag : IndicatorBase
		{
			private int 	linewidth	= 1;	
			private int 	trend;		// confirmed trend of current glZigZagEntry, 1=up, -1=down
			private int 	lhb;   		// last high bar count of last swing high (bars ago = CurrentBar-lhb)
			private int 	prev_lhb;
			private int		uplineid;	// last used up line (name) id
			private int 	llb;   		// last low bar count of last swing low (bars ago = CurrentBar-llb)
			private int 	prev_llb;
			private int		downlineid;	// last used down line name
		    private double 	hh;			// New Higher high
			private double 	prev_hh;
		    private double 	ll;			// New lower low
			private	double	prev_ll;
			
			private double	HLPivot;	// The high-low pivot level switch
			private	AlexKamunyaStrategy1v3	ind;
			public	Series<double> output;
			
			
			public	int		upBar{get;set;}
			public	int		dnBar{get;set;}
			
			public	Series<double> output2;
			
			public	int		direction_index{get;set;}
			public	int		upBar2{get;set;}
			public	int		dnBar2{get;set;}
			
			public 	Dictionary<int,double> Points;
			public 	Dictionary<int,int> Indices;
			
			public	Series<double> maxPriceH;
			public	Series<double> minPriceL;
			public	Series<double> state;
			
			public	bool	confirmed	{get;set;}
			
			
			public Zigzag(AlexKamunyaStrategy1v3 ind)
			{
				this.ind	=	ind;
				output		=	new Series<double>(ind,MaximumBarsLookBack.Infinite);
				Points		=	new Dictionary<int,double>();
				Indices		=	new Dictionary<int,int>();
				
				
				
				maxPriceH		=	new Series<double>(ind,MaximumBarsLookBack.Infinite);
				minPriceL		=	new Series<double>(ind,MaximumBarsLookBack.Infinite);
				state			=	new Series<double>(ind,MaximumBarsLookBack.Infinite);
				
				confirmed		=	true;
			}
			
			public int GetCurrentTrend()
			{
				return trend;
			}
			
			public int GetCurrentLlb()
			{
				return llb;
			}
			
			public int GetCurrentLhb()
			{
				return lhb;
			}
			
			public double GetHLPivot()
			{
				return HLPivot;
			}
			
			public double GetLastDif()
			{
				return direction_index > 1 ? ind.Instrument.MasterInstrument.RoundToTickSize(Points[direction_index] - Points[direction_index-1]) : 0;
			}
			
			public void ZigZagUpdate(int CurrentBar, 
				ISeries<double> PriceH, ISeries<double> PriceL, double ZZPercent, double absoluteReversal, int ATRPeriod, double ATRFactor, int tickReversal, double atr, double close0)
			{
				if (CurrentBar < 1) // minimum 2 bars required
				{
					ll = PriceL[0];
					hh = PriceH[0];
					llb = lhb = 0;
					return;
				}
				if (CurrentBar < 2) // trend start based on bar 2
				{
					if (PriceH[0] >= hh) 
					{
						hh = PriceH[0];
						lhb = 1;
						trend = 1;
					}
					else 
					{
						ll = PriceL[0];
						llb = 1;
						trend = -1;
					}
					uplineid = downlineid = CurrentBar;
				}

				// ATR factor = 0, only use percent setting
				if (ATRFactor == 0) 
					HLPivot = (ZZPercent/100.0);
				// Zigzag percent = 0, only use ATR
				else if (ZZPercent == 0) 
					HLPivot = atr/close0*ATRFactor;
				// Use both influences
				else HLPivot = ZZPercent/100.0 + atr/close0*ATRFactor; 
				
				double absReversal;
				if (absoluteReversal != 0) 
				{
				    absReversal = absoluteReversal;
				} 
				else 
				{
				    absReversal =  tickReversal * ind.TickSize;
				}

				// --------------------------------------------------------------------------------
				// look for swing points and draw lines
				// trend is up, look for new swing low
				if (trend > 0 || 
					(llb == CurrentBar && !(PriceL[0] < hh - hh*HLPivot - absReversal)  ) ||
					!confirmed) 		
				{ 
					
					if (PriceH[0] >= hh) 
					{	
						
						
						// new higher high detected
						hh = PriceH[0];
						lhb = CurrentBar;
						
						
						//prev high trend was continued
						if(((llb == CurrentBar && !(PriceL[0] < hh - hh*HLPivot - absReversal)) && confirmed && trend < 0) ||
							(!confirmed && trend < 0))
						{
							ll		=	prev_ll;
							llb		=	prev_llb;
							trend	=	1;
							
							Points.Remove(direction_index);
							Indices.Remove(direction_index);
							direction_index --;
							
						}
						
						if(trend > 0)
						{
							//approach2
							upBar2		=	CurrentBar;
							
							//approach3
							Points[direction_index]=PriceH[0];
							Indices[direction_index]=CurrentBar;
							
							if (PriceH[0] > ll + ll*HLPivot + absReversal && !confirmed)  
							{
								confirmed	=	true;
							}
						}
						
						
//						ind.Print(ind.Time[0] + "new higher high detected " + "Confirmed = "+confirmed + "trend = "+trend);
					}
					
					else if (PriceL[0] < hh - hh*HLPivot - absReversal && confirmed) 
					{	
						
						
						// found a swing low
						prev_ll		=	ll;
						prev_llb	=	llb;
						ll 			= 	PriceL[0];
						llb 		= 	CurrentBar;
						downlineid 	= 	CurrentBar;
						trend 		= 	-1;
						
						//approach1
						output[0]	=	1;
						upBar		=	lhb;
						
						
						//approach2
						direction_index ++;
						dnBar2		=	llb;
						
						//approach3
						Points.Add(direction_index,PriceL[0]);
						Indices.Add(direction_index,CurrentBar);
						
						confirmed	=	true;
						
//						ind.Print(ind.Time[0] + "Low was broken. New Down Trend. Confirmed = true ");
					}
					
					else if (PriceH[0] < hh && confirmed)
					{
						trend		=	-1;
						confirmed	=	false;
						
						prev_ll		=	ll;
						prev_llb	=	llb;
						ll 			= 	PriceL[0];
						llb 		= 	CurrentBar;
						
						direction_index ++;
						
						Points.Add(direction_index,PriceL[0]);
						Indices.Add(direction_index,CurrentBar);
						
//						ind.Print(ind.Time[0] + "Unconfirmed Down Trend. Confirmed = false ");
					}
					
					else if(trend > 0 && !confirmed)
					{
						Points[direction_index]		=	PriceH[0];
						Indices[direction_index]	=	CurrentBar;
					}
				}

				// else trend is down, look for new swing high
				if(trend < 0 || 
					(lhb == CurrentBar && !(PriceH[0] > ll + ll*HLPivot + absReversal)  ) ||
					!confirmed)
				{
					
					
					
					if (PriceL[0] <= ll)  
					{
						
						// new lower low detected
						ll = PriceL[0];
						llb = CurrentBar;
						
						
						
						//prev high trend was continued
						if((lhb == CurrentBar && !(PriceH[0] > ll - ll*HLPivot + absReversal) && confirmed) ||
							(!confirmed && trend > 0))
						{
							hh		=	prev_hh;
							lhb		=	prev_lhb;
							trend	=	-1;
							
							Points.Remove(direction_index);
							Indices.Remove(direction_index);
							direction_index --;
						}
						
						
						if(trend < 0)
						{
							//approach2
							dnBar2						=	CurrentBar;
							
							
							//approach3
							
							Points[direction_index]		=	PriceL[0];
							Indices[direction_index]	=	CurrentBar;
							
							
							if (PriceL[0] < hh - hh*HLPivot - absReversal && !confirmed) 
							{
								confirmed	=	true;
							}
						}
						
//						ind.Print(ind.Time[0] + "new lower low detected " + "Confirmed = "+confirmed + "trend = "+trend);
						
					}
					else if (PriceH[0] > ll + ll*HLPivot + absReversal && confirmed)  
					{
						
						// found a swing high
						prev_hh		=	hh;
						prev_lhb	=	lhb;
						hh 			= 	PriceH[0];
						lhb 		= 	CurrentBar;
						uplineid 	= 	CurrentBar;
						trend 		= 	1;
						
						//approach1
						output[0]	=	-1;
						dnBar		=	llb;
						
						
						//approach2
						direction_index ++;
						upBar2		=	lhb;
						
						//approach3
						Points.Add(direction_index,PriceH[0]);
						Indices.Add(direction_index,CurrentBar);
						
						confirmed	=	true;
						
//						ind.Print(ind.Time[0] + "High was broken. New Up Trend. Confirmed = true ");
					}
					
					else if(PriceL[0] > ll && confirmed)
					{
						trend		=	1;
						confirmed	=	false;
						
						prev_hh		=	hh;
						prev_lhb	=	lhb;
						hh 			= 	PriceH[0];
						lhb 		= 	CurrentBar;
						
						direction_index ++;
						
						Points.Add(direction_index,PriceH[0]);
						Indices.Add(direction_index,CurrentBar);
						
//						ind.Print(ind.Time[0] + "Unconfirmed Up Trend. Confirmed = false ");
					}
					else if(trend < 0 && !confirmed)
					{
						Points[direction_index]		=	PriceL[0];
						Indices[direction_index]	=	CurrentBar;
					}
					
				}
				
				
				
				
				
				
				
				
				
				
				
				
//				state[0]	=	0;
				
//				bool newMax;
//				bool newMin;
				
//				double prevMaxH	=	maxPriceH[1];
//				double prevMinL	=	minPriceL[1];
				
//				if(state[1] == 0)
//				{
//					maxPriceH 	=	PriceH[0];
//					minPriceL	=	PriceL[0];	
//					newMax		=	true;
//					newMin		=	true;
//					state[0]	=	1;
//				}
//				else if(state[1] == 1)
//				{
//					if(PriceH[0] >= prevMaxH)
//					{
//						state[0] = 2;
//						maxPriceH[0] 	=	PriceH[0];
//						minPriceL[0]	=	prevMinL;
//						newMax			=	true;
//						newMin			=	false;
//					}
//					else if(PriceL[0] <= prevMinL)
//					{
//						state[0]		=	3;
//						maxPriceH[0] 	= 	prevMaxH;
//						minPriceL[0] 	= 	PriceL[0];
//						newMax			=	false;
//						newMin			=	true;
//					}
//					else
//					{
//						state[0]		=	1;
//						maxPriceH[0]	=	prevMaxH;
//						minPriceL[0]	=	prevMinL;
//						newMax			=	false;
//						newMin			=	false;
//					}
					
//				}
//				else if(state[1] == 2)
//				{
//					if(PriceL[0] <= prevMaxH - prevMaxH * hlPivot - absReversal)
//					{
//						state			=	3;
//						maxPriceH[0]	=	prevMaxH;
//						minPriceL[0]	=	PriceL;
//						newMax			=	false;
//						newMin			=	true;
						
//					}
//					else
//					{
//						state			=	2;
//						if(PriceH[0] 	>= prevMaxH)
//						{
//							maxPriceH[0] 	= PriceH[0];
//							newMax			=	true;
//						}
//						else
//						{
//							maxPriceH[0]	=	prevMaxH;
//							newMax			=	false;
//						}
//						minPriceL[0]	=	prevMinL;
//						newMin			=	false;
//					}
//				}
//				else
//				{
//					if(PriceH[0] >= prevMinL + prevMinL * hlPivot + absReversal)
//					{
//						state[0]		=	2;
//						maxPriceH[0]	=	PriceH[0];
//						minPriceL[0]	=	prevMinL;
//						newMax			=	true;
//						newMin			=	false;
//					}
//					else
//					{
//						state 			=	3;
//						maxPriceH[0]	=	prevMaxH;
//						newMax			=	false;
//						if(PriceL[0] < prevMinL)
//						{
//							minPriceL[0] 	= PriceL[0];
//							newMin			=	true;
//						}
//						else
//						{
//							minPriceL[0]	=	prevMinL;
//							newMin			=	false;
//						}
//					}
//				}
			}
		}
		#endregion
		
		#region Trade
			public class TradeHandler{
				private List<Trade> 			trades;
				private AlexKamunyaStrategy1v3 	s;
				
				public TradeHandler(AlexKamunyaStrategy1v3 s){
					trades 	= new List<Trade>();
					this.s 	= s;
				}
				
				public void AddTrade(Trade trade){
					trades.Add(trade);
				}
				
				public void OnTick(){
					foreach (Trade trade in trades){
						trade.OnTick();
					}
				}
			}
		
			public class Trade{
				private AlexKamunyaStrategy1v3 	s;
				
				public Trade(AlexKamunyaStrategy1v3 s){
					this.s 	= s;
				}
				
				public void OnTick(){
					
				}
			}
			
		#endregion
		#endregion
		
		#region Properties
			
			#region Parameters
			
			const string par1	= "Parameters";
		
			[NinjaScriptProperty]
			[Display(ResourceType = typeof(Custom.Resource), Name="Debug Log", Order=1, GroupName=par1)]
	        public bool pmEnableLog
	        { get; set; }
			
			[NinjaScriptProperty]
			[Range(1,int.MaxValue)]
			[Display(ResourceType = typeof(Custom.Resource), Name="# of Contracts", Order=20, GroupName=par1)]
	        public int pmLot
	        { get; set; }
			
			[NinjaScriptProperty]
			[Display(ResourceType = typeof(Custom.Resource), Name="Enable Trend Filter", Order=30, GroupName=par1)]
	        public bool pmEnableTrendFilter
	        { get; set; }
			
			[NinjaScriptProperty]
			[Range(0,int.MaxValue)]
			[Display(ResourceType = typeof(Custom.Resource), Name="Trend Filter Ticks Offset", Order=33, GroupName=par1)]
	        public int pmTrendFilterTicksOffset
	        { get; set; }
			
			[NinjaScriptProperty]
			[Display(ResourceType = typeof(Custom.Resource), Name="Position Type", Order=40, GroupName=par1)]
	        public EnumDirectionType pmDirectionType
	        { get; set; }
			
			[NinjaScriptProperty]
			[Range(0, int.MaxValue)]
			[Display(ResourceType = typeof(Custom.Resource), Name="Take Profit (ticks)", Order=63, GroupName=par1)]
			public int pmTakeProfit
			{ get; set; }
			
			[NinjaScriptProperty]
			[Display(ResourceType = typeof(Custom.Resource), Name="Position Type", Order=55, GroupName=par1)]
	        public EnumStopLossType pmStopLossType
	        { get; set; }
			
			[NinjaScriptProperty]
			[Range(0, int.MaxValue)]
			[Display(ResourceType = typeof(Custom.Resource), Name="Hard Stop Loss (ticks)", Order=57, GroupName=par1)]
			public int pmStopLoss
			{ get; set; }
			
			[NinjaScriptProperty]
			[Range(0, int.MaxValue)]
			[Display(ResourceType = typeof(Custom.Resource), Name="SR Zone Offset (ticks)", Order=59, GroupName=par1)]
			public int pmStopLossOffset
			{ get; set; }
			
			[NinjaScriptProperty]
			[Display(ResourceType = typeof(Custom.Resource), Name="Enable Zone Target", Order=70, GroupName=par1)]
	        public bool pmEnableZoneTarget
	        { get; set; }
			
			
			
			#endregion
			
			#region Indicators
			
			const string par2_1	= "Entry: SupplyDemandFibExtensions";
			
			[NinjaScriptProperty]
			[Display(Name="Calculate", Order=1, GroupName=par2_1)]
			public Calculate pmSdfen_Calculate
			{ get; set; }
			
			[NinjaScriptProperty]
			[Display(Name="percentamount", Order=2, GroupName=par2_1)]
			public double pmSdfen_percentamount
			{ get; set; }
			
			[NinjaScriptProperty]
			[Display(Name="revAmount", Order=3, GroupName=par2_1)]
			public double pmSdfen_revAmount
			{ get; set; }
			
			[NinjaScriptProperty]
			[Display(Name="atrreversal", Order=4, GroupName=par2_1)]
			public double pmSdfen_atrreversal
			{ get; set; }
			
			
			[NinjaScriptProperty]
			[Display(Name="atrlength", Order=5, GroupName=par2_1)]
			public int pmSdfen_atrlength
			{ get; set; }
		
			
			const string par2_2	= "Exit: SupplyDemandFibExtensions";
			
			[NinjaScriptProperty]
			[Display(Name="Calculate", Order=1, GroupName=par2_2)]
			public Calculate pmSdfex_Calculate
			{ get; set; }
			
			[NinjaScriptProperty]
			[Display(Name="percentamount", Order=2, GroupName=par2_2)]
			public double pmSdfex_percentamount
			{ get; set; }
			
			[NinjaScriptProperty]
			[Display(Name="revAmount", Order=3, GroupName=par2_2)]
			public double pmSdfex_revAmount
			{ get; set; }
			
			[NinjaScriptProperty]
			[Display(Name="atrreversal", Order=4, GroupName=par2_2)]
			public double pmSdfex_atrreversal
			{ get; set; }
			
			
			[NinjaScriptProperty]
			[Display(Name="atrlength", Order=5, GroupName=par2_2)]
			public int pmSdfex_atrlength
			{ get; set; }
		
			
			
			const string par3	= "gbChandelierStop";
			[NinjaScriptProperty]
			[Range(1, int.MaxValue)]
			[Display(Name="Lookback", Description="Lookback for period to find highs or lows; also used for ATR.", Order=1, GroupName=par3)]
			public int pmGcsLookback
			{ get; set; }
			
			[NinjaScriptProperty]
			[Range(0, double.MaxValue)]
			[Display(Name="ATR Multiple", Description="Multiple for ATR.", Order=2, GroupName=par3)]
			public double pmGcsMultipleATR
			{ get; set; }
			
			[NinjaScriptProperty]
			[Display(Name="Use Ticks instead of ATR", Description="Use fixed number of ticks instead of ATR.", Order=3, GroupName=par3)]
			public bool pmGcsUseTicks
			{ get; set; }
			
			[NinjaScriptProperty]
			[Range(1, int.MaxValue)]
			[Display(Name="Number of Ticks", Description="Number of ticks to use.", Order=4, GroupName=par3)]
			public int pmGcsNbrOfTicks
			{ get; set; }
			
			[NinjaScriptProperty]
			[Display(Name="Color Background", Description="", Order=3, GroupName=par3)]
			public bool pmGcsColorBG
			{ get; set; }
			
	
			#endregion
		
		#endregion
	}
}
